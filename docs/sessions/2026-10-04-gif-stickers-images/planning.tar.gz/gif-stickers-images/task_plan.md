# GIF Stickers 1.3.0

Goal: support still-image stickers and cached on-device subject cutout; prepare one PR, verify CI, and report to main. Never install, send WhatsApp messages, merge, tag or release.

## Phases
1. Inspect asset, encoder, UI, tests and worktree workflow — complete.
2. Implement still inputs and optional cached subject cutout — complete.
3. Add generated-fixture tests and release documentation/metadata — complete.
4. Verify tests, version gate and isolated UI — complete (visual check skipped at user direction).
5. Commit, open PR, wait for CI, report to main — complete; close-out deferred until feature PR is merged.

## Errors
- SwiftPM nested sandbox refused; use approved execution with worktree cache.

- Generic HEIF destination is not writable; generate HEIC data with .heif filename to test the family.
- Computer Use denied GIF Stickers app access; isolated visual UI check remains unverified.
- First CI run failed only Vision inference availability on hosted VM; narrow exact-error skip and runtime disabled-toggle fallback added.
