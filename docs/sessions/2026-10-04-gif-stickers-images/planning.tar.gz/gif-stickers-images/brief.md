# GIF Stickers 1.3.0: stickers from still images, with an optional "Cut out subject"

User-requested. One PR. Work only in gif-stickers/ plus release metadata.

## Background
WhatsApp supports static stickers: 512x512 WebP, at most 100 KB (animated:
at most 500 KB). GIF Stickers already produces static stickers from one-frame
GIFs (Engine.swift; testStaticCapAndLongTrim), the library already accepts
static WebP on import, and Send to my WhatsApp (SayWhatClient, kind=sticker,
image/webp) works for static WebP. What is missing is the INPUT side:
AnimationAsset.openableTypes is only [.gif] + video types, so a PNG/JPEG/HEIC
is rejected with "Choose a GIF or a short video".

## 1. Still images in
- Accept PNG, JPEG, HEIC/HEIF, TIFF and static WebP in File > Open, the
  empty-frame click, drag and drop, Dock drops and Open With (update
  Info.plist CFBundleDocumentTypes with LSHandlerRank Alternate, and the
  README). Animated WebP input may be rejected with a clear message unless
  trivial.
- Decode via ImageIO, apply EXIF orientation so photos are upright, cap the
  decoded size sensibly (e.g. 2048 px long side) to keep memory low, and model
  a still image as a one-frame asset so the existing crop / fit framing,
  preview, encoder, Add to Library and Send all work unchanged.
- The exported sticker must be static WebP, exactly 512x512, at most 100 KB,
  with alpha preserved (PNG/HEIC transparency; fit mode's transparent padding).
  Reuse the adaptive quality loop; static has only the quality axis.
- Update UI copy ("GIF, video or image").

## 2. "Cut out subject" (still images only)
- A toggle, off by default, visible when a still image is loaded. When on,
  remove the background with Vision's subject lifting:
  VNGenerateForegroundInstanceMaskRequest (macOS 14+, on-device), using all
  detected instances, and apply the mask to the image so the background is
  transparent before framing.
- If no subject is found, say so and keep the original. Run it off the main
  thread; cache the result per image so toggling and re-framing are instant.
- Optionally a thin white sticker outline around the cut-out (classic sticker
  look) as a second toggle, off by default. Keep it simple; skip if it adds
  real risk.
- Tests: a synthetic image (e.g. a filled shape on a flat background) proving
  the mask path yields transparent corners and opaque subject pixels, guarded
  so the test skips cleanly if Vision returns no instances on the CI runner
  (macos-14), and a unit test of the mask-application code independent of
  Vision.

## Tests and verification
- Encoder/asset tests for PNG with alpha, JPEG, HEIC (generate fixtures in
  tests with ImageIO, no binary fixtures), EXIF orientation, static <=100 KB,
  exactly 512x512, alpha kept, and that animated inputs still behave as before.
- Library import of the static result, and the SayWhat stub test accepting a
  static sticker.
- Isolated UI check from your worktree's build only. Do NOT install into
  ~/Applications or touch live installs (installs change only via releases).
  No real WhatsApp sends.

## Release prep
gif-stickers/mac-utility.json -> 1.3.0; VERSION -> 1.3.0; install.sh
SCRIPT_VERSION -> "v1.3.0"; [1.3.0] entry at the top of CHANGELOG.md;
scripts/release/version_gate.py --tag v1.3.0 must pass. Update README.

## Rules
Follow AGENTS.md (incl. /bin/bash 3.2). The GitHub runner's Swift is older:
no captured mutable vars in concurrent closures; build in Swift 5 language
mode. Public repo: no personal data, no personal photos in tests or docs.
Commit with the configured no-reply identity; one PR to main; never merge,
tag or release. Planning in gitignored root task_plan.md / findings.md /
progress.md. Report the PR URL to (main) when CI is green.
