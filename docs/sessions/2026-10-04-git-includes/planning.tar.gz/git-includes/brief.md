# Git & SSH: manage included config files and includeIf rules (ship as v1.1.0)

## Goal
The user's `~/.gitconfig` uses a conditional include to switch identity for
public work:

    [includeIf "gitdir:~/workspace/mac-utilities/"]
        path = ~/.gitconfig-public

and `~/.gitconfig-public` holds a `[user] email = ...` override. The Git & SSH
app (git-settings/) today edits only values stored directly in
`~/.gitconfig`; it preserves includes but cannot show or edit them. Make the
app manage this setup.

## Deliverables
1. **Show the include structure.** In Git Settings, list every `include.path`
   and `includeIf.<condition>.path` in `~/.gitconfig`: the condition (gitdir:,
   gitdir/i:, onbranch:, hasconfig:remote.*.url:), the target file, whether it
   exists, and which values it overrides (e.g. user.email, signing key).
2. **Edit included files.** Open an included file as its own profile and edit
   the same supported keys (identity, signing, etc.) with the existing
   preview / apply / restore transaction, lock and symlink refusal, and stale-
   preview checks. Only files referenced from ~/.gitconfig and located under
   the home folder may be edited; refuse anything else.
3. **Manage rules.** Add, change and remove include/includeIf rules in
   ~/.gitconfig, including creating a new profile file (e.g. a second
   directory that should use ~/.gitconfig-public). Validate conditions and
   paths; never write values that git would reject; keep unrelated content and
   ordering untouched. Removing a rule never deletes the target file.
4. **Effective identity check.** Given a folder (picker), show which identity
   git would use there (`git -C <dir> config --show-origin --show-scope
   user.email` style, read-only), so the user can confirm a public repo
   resolves to the no-reply address.
5. **Tests** in GitSettingsCoreTests with fixture homes only (example.com
   emails). Never read or write the real ~/.gitconfig in tests.
6. **Release prep for v1.1.0:** bump git-settings/mac-utility.json to 1.1.0,
   VERSION and install.sh SCRIPT_VERSION to 1.1.0, add a CHANGELOG entry, and
   make sure scripts/release/version_gate.py passes with --tag v1.1.0.
   Update git-settings/README.md.

## Rules
- Follow AGENTS.md, including the new Bash 3.2 rule. Work only on this branch;
  one PR to main on penard-monkey/mac-utilities (now PUBLIC: no personal
  emails, paths or names in code, tests, docs or commit messages; your
  commits use the no-reply identity already configured).
- Never modify the user's real ~/.gitconfig or ~/.gitconfig-public while
  developing or testing; use isolated homes. A read-only look at their
  structure is fine.
- No tags, releases or merges. Planning in gitignored root task_plan.md /
  findings.md / progress.md.

## When to stop
PR open with CI green, all suites passing, and the app's new screens checked
in an isolated fixture home. Report to (main) via worktrees report.
