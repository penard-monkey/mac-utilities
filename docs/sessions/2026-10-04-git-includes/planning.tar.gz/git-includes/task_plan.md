# Task Plan: Git includes v1.1.0

## Goal
Manage direct Git include rules, safely edit home-contained referenced profiles, check folder identity, and open one PR with all suites and CI green. No host Git writes, tags, releases or PR merges; merge origin/main after hotfix #3 lands as explicitly requested.

## Next Step
PR #5 is open and green at 8e0082d, with latest main (#3 and #4) incorporated. Coordinating place will review and merge; archive close-out remains deferred until merged per the skill precondition.

## Phases
### Phase 1: Inspect design and Git semantics
**Status:** complete
### Phase 2: Core operations and fixture regression tests
**Status:** complete
### Phase 3: Native screens, README and release metadata
**Status:** complete
### Phase 4: Full suites, isolated UI verification, PR and CI
**Status:** complete
### Phase 5: Close-out assessment and report to main
**Status:** complete (assessment done; archive deferred until merged)

## Decisions
- Stay in the existing git-includes place and branch.
- Use existing single-file transactions; add a rule referencing a missing profile, then create it through the profile editor.
- Restrict editing to direct references from the primary config within the fixture/user home; revalidate authorization at apply and restore.

## Errors Encountered
| Error | Attempt | Resolution |
|---|---|---|
| Assumed build.sh exists | 1 | Use utility install.sh and SwiftPM directly |

- Steering: merge origin/main after #3 (Transcribe v1.0.1) lands; retain v1.1.0 as release target.
| Full release suite failed: utility fixture bundle was hardcoded to 1.0.0 | 1 | Use manifest version for utility fixtures |
| Condition examples rendered tildes as Markdown strikethrough | 1 | Use Text(verbatim:) |
| Native modal folder picker became unresponsive | 1 | Present asynchronously via NSOpenPanel.begin |
| Copied fixture executable terminated on restart | 1 | Re-sign the locally rebuilt bundle after replacement |
| CRLF regression failed to locate rule | 1 | Treat CRLF grapheme as isNewline in scanner |
| Fixture UI tools attached to an older instance | 1 | Stop both test instances and relaunch one current bundle |
