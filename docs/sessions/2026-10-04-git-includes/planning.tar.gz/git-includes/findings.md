# Findings

## Requirements
- Include inventory supports unconditional, gitdir, gitdir/i, onbranch and hasconfig rules, existence and direct supported overrides.
- Profile edits reuse preview/apply/restore and refuse locks, symlinks, stale previews and unauthorized paths.
- Rule edits preserve unrelated bytes and order; removal preserves profiles.
- Folder picker checks Git identity with origin/scope read-only.
- Isolated tests and GUI only, public-safe content, version gate v1.1.0, one PR and green CI.

## Research Findings
- GitService currently has a supported-key allowlist and private staged Git writes.
- TransactionStore locks targets and compares before/after bytes, but currently has no include authorization.
- AppPaths.current supports GIT_SETTINGS_HOME isolated GUI runs.
- Existing tests use temporary homes and /usr/bin/git.
- Root VERSION and install.sh version gate controls distribution; per-utility version is independent.

## Technical & Strategic Decisions
| Decision | Rationale |
|---|---|
| Single-file rule and profile previews | Reuses proven transaction behavior without partial multi-file writes |
| Git parses values, scanner locates spans | Git owns syntax semantics while edits preserve surrounding bytes |

## Open Issues
| Issue | Status / Resolution |
|---|---|
| Close-out requires merged work | Brief forbids merges; assess at completion and leave ritual deferred if necessary |

## Sources
- .planning/brief.md
- git-settings/Sources/GitSettingsCore/{GitService,Transactions,ProcessRunner}.swift
- git-settings/Sources/GitSettings/App.swift
- https://git-scm.com/docs/git-config
- Include scanner handles same-line headers, quoted comments, escaped continuations and duplicate path assignments. Canonical Git parsing is used to cross-check occurrence counts.
- Profile backups carry root config bytes as an authorization guard. A root config change requires manual backup recovery even if unrelated to the profile; documented conservative behavior.
- Native Git Settings now has include inventory/rule editor, profile selection and folder picker identity results.
- Read-only override inspection also covers outside-home targets, while editing stays refused.
- UTF-8 refusal protects byte preservation for rule edits in non-UTF-8 configs.
- Existing release/test.sh is the comprehensive repository gate, using Bash 3.2 and isolated tests.
- Git docs prohibit remote URLs in files directly or indirectly included by hasconfig rules. New rule previews reject such files, malformed profiles and recursive includes.
- Native screenshot revealed condition example tildes became Markdown strikethrough; changed to verbatim text. Selecting a profile now scrolls to its editor.
- Release fixture helper hardcoded utility bundle version to 1.0.0 despite copying live manifests. Fixtures now accept the manifest version independently of the manager release.
- Full repository suites passed with 23 GitSettingsCore tests. Native picker cancellation works after switching to asynchronous presentation; directory selection remains under investigation.
- Swift String treats CRLF as one Character. Scanner now uses isNewline to preserve CRLF files correctly.
- Native app lookup found overlapping fixture instances; stopped both and relaunched one before further verification.
- Final native screenshot confirms effective folder identity, origin and scope rendered correctly from the profile. Picker selection itself remains unverified because CUA timed out on the OS file panel; typed folder workflow was verified end to end.
