# Split travel-router out, then prepare the history cleanup for a public mac-utilities

## Why
The user wants mac-utilities public on GitHub, eventually with a release and
update path like penard-monkey/worktrees. A privacy review (2026-10-03) found
no secrets, but personal information that must not go public:

- `travel-router/`: home server public IP and WireGuard port (6 files incl.
  the SwiftBar plugin), the server's WireGuard public key and home LAN
  addresses in `travel-router/brief.md`, two USB adapter MAC addresses in its
  README, [private-exit] as the exit, and a narrative about routing a [private-client] and
  its [private-client]. Also `docs/sessions/2026-10-03-travel-router/`, the travel
  rows in `docs/sessions/index.md` and `ROADMAP.md`.
- Hard-coded username: `com.[local-user].*` labels, `[local-user]` in sudoers and as
  a SUDO_USER fallback (all in travel-router), and in
  `utilities-manager/backend/lifecycle.py` (~line 148) which hard-codes
  `/usr/local/sbin/travel` and `com.[local-user].travel-pf.plist`.
- Commit metadata: author/committer emails 198289462+penard-monkey@users.noreply.github.com and
  198289462+penard-monkey@users.noreply.github.com, `Co-authored-by: penard-monkey <198289462+penard-monkey@users.noreply.github.com>`
  trailers, and `[session-trailer] [private-session-url]` trailers.
- `_tmp` is a committed symlink into the user's iCloud folder.

Travel-router is personal and stays PRIVATE, in its own repo, but the user
still wants it to show up in and be managed by the Mac Utilities manager.

## Deliverables, in order

### 1. Private travel-router repo, history kept
- `git subtree split --prefix=travel-router` from origin/main, push to a NEW
  PRIVATE GitHub repo `penard-monkey/travel-router` (`gh repo create --private`;
  note `gh repo create --source` fails inside worktrees, push to the remote
  instead). Clone it to `~/workspace/travel-router`.
- Move the travel-router session summary and its ROADMAP items into that repo
  (its own `docs/sessions/` and `ROADMAP.md`), plus an AGENTS.md describing it.
- Keep its `mac-utility.json`. It must still install with its own
  `sudo scripts/install.sh` from the new location.

### 2. Manager: catalog sources beyond its own checkout (PR to mac-utilities)
- Today `lifecycle.py` only globs `*/mac-utility.json` and
  `swiftbar/*/mac-utility.json` in one repo. Add extra catalog sources: a
  user file `~/.config/mac-utilities/sources.json` listing directories (each
  scanned the same way, a source being a repo whose root may itself hold a
  `mac-utility.json`). Show the source in the manager UI; let the user add or
  remove a source folder from the app and from `scripts/install.sh`
  (e.g. `scripts/install.sh source add <dir>`). Ids must stay unique across
  sources; report a clash, do not pick silently.
- Remove the hard-coded travel paths from lifecycle.py. A privileged
  manifest declares its own system paths (e.g. `"system_paths": [...]`) and
  travel-router's manifest gets them.
- Tests for both. Follow existing test style; all existing suites stay green.

### 3. Remove travel-router from mac-utilities (PR)
- BEFORE this merges: the live SwiftBar link `~/.swiftbar/travel.30s.sh`
  points into the main checkout's `travel-router/`. Re-point it to
  `~/workspace/travel-router/swiftbar/travel.30s.sh` (a user-level symlink,
  no sudo) and confirm the plugin still runs. Anything that needs sudo, stop
  and ask the user via worktrees report; do not run sudo.
- Delete `travel-router/`, its docs/sessions entry, index row and ROADMAP
  section. Untrack `_tmp` (add `/_tmp` to .gitignore; leave the user's actual
  symlink on disk in every checkout). Update README/AGENTS.md (the "bigger
  utility" example can no longer be travel-router; use gif-stickers or
  git-settings). Register `~/workspace/travel-router` as a catalog source on
  this Mac and show the manager still lists Travel Router.
- Grep the result for the review's patterns (home IP, [private-exit], MACs,
  [local-user], [private-domain], [private-inbox]) and list any leftovers.

### 4. Prepare the history rewrite, do NOT publish it
- In a scratch mirror clone (never in a worktree, never on origin), run
  `git filter-repo`: drop every travel-router path (both `travel-router/` and
  its pre-merge root paths: bin/travel*, brief.md, etc/sudoers-travel,
  launchd/com.[local-user].*, scripts/diag.sh, scripts/reset-baseline.sh,
  scripts/setup-wired.sh, swiftbar/travel.30s.sh and the travel parts of
  scripts/install.sh/uninstall.sh), drop `_tmp`, map both emails to the
  user's GitHub no-reply address (`gh api user` gives id/login), and strip
  `[session-trailer]` trailers and the penard-monkey co-author trailers.
- Re-run the privacy grep over the rewritten FULL history (`git log --all -p`
  plus `--format='%an %ae %cn %ce %b'`) and produce a report: commit count
  before/after, what was removed, any remaining hits.
- Write the exact cut-over steps for the user: when (after the qr-reader and
  audio-transcription lanes merge), force-push commands, how every worktree
  and open branch gets recreated, and the separate step of flipping the repo
  public plus adding a LICENSE (ask which license).

## Rules
- Follow AGENTS.md. Commit only on your branch; normal PRs to main for
  steps 2 and 3. You may merge neither; report PR URLs.
- NEVER force-push, rewrite origin, delete remote branches you did not
  create, change any repo's visibility, or run sudo. Those are the user's
  calls; stop and report.
- Planning in gitignored root task_plan.md / findings.md / progress.md.
- Other lanes are active (qr-reader, audio-transcription; done:
  git-management, utilities-manager, git-settings-app). Do not touch their
  worktrees.

## When to stop
After step 4's report and cut-over plan, with PRs for steps 2 and 3 open and
the private repo pushed. Report to (main) via worktrees report. Stop earlier
and report if any step needs a decision only the user can make.
