# Public preparation

1. [complete] Extract travel-router from origin/main with history; create private repository and independent checkout; move its documentation.
2. [complete] Add external catalog sources, app/CLI source management, unique IDs and manifest system paths; test and open manager PR #15 (unmerged).
3. [complete with handoff] Private source registered, removal PR #16 open, inbox untracked/preserved, privacy scan recorded. Live plugin visual check remains assigned to user; no plugin execution.
4. [complete] Final scratch mirror audited: 68 to 33 commits across all fetched refs, zero privacy hits. Cut-over report and reusable filter/audit/print-only push helpers prepared; nothing published.
5. [complete] Report and reproducibility kit handed back through _tmp; preparing the required redacted session archive PR and final report to main. No merges, sudo, force pushes, or visibility changes. Remaining publication actions are explicit user handoffs.

## Resume point
- Manager PR: https://github.com/penard-monkey/mac-utilities/pull/15, commit cad49b3.
- Private repo: https://github.com/penard-monkey/travel-router, stable main 8ec4477.
- Plugin execution remains prohibited; visual verification is a user handoff and must be stated as pending rather than claimed complete.
- Continue the remaining authorized work that does not depend on running sudo. Coordinating place requests source registration before removal merges.

## Decisions and constraints
- Work only in owned places. Other lanes remain untouched.
- Two ordinary PRs remain open. Scratch rewrite is never pushed.
- Stop and report if sudo or a user-only decision becomes necessary.

## Errors
- Git writes were sandbox denied; authorized escalation worked.
- Transient GitHub 503 responses; retries through REST resolved identity and repository creation.
- worktrees new declined a default agent due to allowance; place created, no override needed.
- Test/doc patch had a mismatched README context; reapplied corrected patch.
- New clone retained its original single-branch fetch ref; correcting remote refspec to fetch main.
- GIF video fixture creation failed under the filesystem sandbox; all 8 tests passed on an unsandboxed rerun, without source changes.
- First worktrees report call used message rather than text; corrected API argument and report was filed.
- Scratch runner initially queried a removed remote config key with a checked command; replaced it with a no-remotes guard.
- First privacy rehearsal had zero initial pattern hits but preserved three pre-subtree private commits through .gitignore changes. Expanded audit to work-routing narrative and explicitly pruned all private-root commit changes; rerunning from untouched before mirror.
- Scratch preview bundle creation initially missed the actual Swift build output layout; locating the existing executable without rebuilding.
