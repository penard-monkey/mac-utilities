# GIF Stickers v1.2.0
- [x] Implement direct library add, safe collision naming, guarded rename and name sorting.
- [x] Add library selection/scroll and rename sheet; preserve existing library actions.
- [x] Add temporary-folder tests; update README and release versions.
- [x] Run Swift 5 tests, shell syntax and release version gate; review diff.
- [x] Commit, push, open one PR, wait for green CI and report to main.
- Close-out follows after merge: brief prohibits merging, so archive PR cannot run yet.
