# GIF Stickers: "Add to Library" instead of Export, and rename in the library (v1.2.0)

User-requested UI changes to gif-stickers/. One PR.

## 1. Export Sticker -> Add to Library
Today `EditorModel.save()` (App.swift ~75) opens an NSSavePanel, writes the
file, copies it and reveals it; StickerLibrary.save also stores a copy.
Replace that flow:
- The button (App.swift ~316, and the menu item at ~135, keep Cmd-S) becomes
  "Add to Library". It writes the current previewed WebP straight into the
  library folder via StickerLibrary, with NO dialog, no Finder reveal and no
  clipboard copy.
- Default name: the source file's base name, made safe for a filename; on a
  collision append " 2", " 3", ... Never overwrite.
- Confirm in the status line ("Added '<name>' to the library") and make the new
  sticker visible/selected when the Library view is shown.
- Disabled while there is no current preview (as Export was).
- Keep the Library's existing Send, Copy, Reveal, Delete and import.

## 2. Rename in the library
- Each library item gets Rename (context menu and a button or double-click on
  the name). Inline edit or a small sheet, your call; Return commits, Escape
  cancels.
- Rename moves the file within the library folder only. Keep the .webp
  extension (the user edits only the name). Reject empty names, path
  separators, leading dots, control characters and names over 200 characters
  with a clear message; refuse a name that already exists (case-insensitive,
  as the default macOS filesystem is) instead of overwriting.
- The grid sorts by name so renamed stickers are easy to find. Names will be
  used for search later; no search field in this PR.

## Tests
StickerLibrary tests in temporary folders for: add without dialog, default
naming and collision suffixes, rename success, every rejection rule,
case-insensitive collision, and that rename never leaves the library folder.

## Release prep
gif-stickers/mac-utility.json -> 1.2.0; VERSION -> 1.2.0; install.sh
SCRIPT_VERSION -> "v1.2.0"; new [1.2.0] entry at the top of CHANGELOG.md;
scripts/release/version_gate.py --tag v1.2.0 must pass. Update
gif-stickers/README.md (Add to Library, rename).

## Rules
Follow AGENTS.md, including the /bin/bash 3.2 rule. The GitHub runner's Swift
is older than local: no captured mutable vars in concurrent closures; build
in Swift 5 language mode. Public repo: no personal data. Do not install into
~/Applications or touch live installs (installs change only via releases).
No real WhatsApp sends. Commit with the configured no-reply identity on this
branch; one PR to main; never merge, tag or release. Planning in gitignored
root task_plan.md / findings.md / progress.md. Report the PR URL to (main)
when CI is green.
