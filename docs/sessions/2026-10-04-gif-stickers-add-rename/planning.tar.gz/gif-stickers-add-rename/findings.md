# Findings
- Existing save uses NSSavePanel, export copy, clipboard and Finder reveal; library filenames carry UUIDs.
- Library has no selection and sorts newest first. Shared library store is injected in LibraryModel; inject it into EditorModel for isolated save tests.
- Worktree is clean on gif-stickers-add-rename; configured identity is GitHub no-reply.
- Close-out skill requires merged feature work and a separate archive PR. Brief explicitly requires one feature PR and no merge; defer ritual until after merge.
- Names are bounded by both 200 characters and the filesystem's 255-byte component limit. Adds reserve byte/character space for numbered suffixes.
- Library labels now reflect actual filename stems, including old UUID filenames, so accepted rename text is always displayed faithfully.
- Foundation may enumerate /private/var paths but return /var aliases from URL normalization. Normalize listed sticker URLs too; otherwise the selected save URL does not equal the tile ID.
- First sandboxed full suite could not create existing AVFoundation video/stub-server fixtures. Unsandboxed native SwiftPM build runs these; moved Xcode scratch data stalled and was replaced with fresh native-build cache.
