# Progress Log

## Session: 2026-10-03
- Received (main)'s brief: general file transcriber as a mac-utilities utility (SwiftUI app + SwiftBar), engine as dependency, plan first, merge main after git-management lands.
- Checked engine (healthy, launchd), saywhat overlap (none beyond the engine), manager manifest contract (app + plugin allowed together).
- Wrote task_plan.md / findings.md. Next: report to (main) with plan summary + 4 scope questions; wait for git-management PR before merging main.
- Reported plan + 4 scope questions to (main) (message <number>-8efc-00000000). Waiting on the user and on the git-management PR.
- PR #12 landed. Fast-forwarded to origin/main dc3e859. Verified manifest dependency paths must be absolute. Still waiting on the user's scope answers before building.
- the user: bring the engine into mac-utilities. Inventoried audio-notes server/CLI, deps, model cache, saywhat coupling (it installs the launchd job). Options E1–E3 in findings; plan updated with questions 5–8. Reported to (main).
- Built transcribe/: engine/server.py (stdlib HTTP + mlx-whisper, same contract), engine/cli.py (`transcribe`), Swift app (Engine.swift core + App.swift), swiftbar/transcribe.10s.py, install/uninstall scripts, launchd template, manifest.
- mlx-whisper runs without torch (only torch_whisper.py imports it): venv 467 MB vs 1.5 GB. Warm voice note ~0.7 s; cold first run 34 s incl. model download.
- install-engine.sh run for real: audio-notes job retired (plist in ~/.cache/mac-utilities/transcribe/replaced/), com.mac-utilities.transcribe live, ~/.local/bin/transcribe linked (shadows ~/bin/transcribe).
- saywhat verified unchanged: status/doctor/transcribe all OK against the new engine.
- Manager: isolated --home install/uninstall OK (app + plugin from one manifest); real `install transcribe` OK.
- Bug found+fixed: SwiftUI lifecycle delivers Open With via application(_:open:) not openFiles; argv files arrive as an open event too (handling argv duplicated jobs). Guard against re-queuing a busy file.
- Gates: swift test transcribe 8/8, engine unittest 8/8, manager tests OK, bash -n, py_compile.
- Not verified visually: screencapture denied in this shell.
- Removed 11 test entries from the real history.
- PR #17 opened. Reported to (main) and to sw:(main) (saywhat installer change). Waiting on review/merge; then close-out.
- uninstall/reinstall round trip OK; uninstall now waits for launchd. ~/bin/transcribe deleted (fresh login shell finds ~/.local/bin/transcribe). audio-notes README marked deprecated (local commit 79e5fe5, not pushed), dir renamed to ~/workspace/audio-notes-deprecated. saywhat lane sw:retire-audio-notes created with brief; agent NOT started (Claude at 79% weekly) — waiting on the user: codex/pi/force.
- Merged origin/main (#15, #16) into audio-transcription; README conflict resolved, manager intro fixed (5 bundled + external sources). Gates green. PR #17 MERGEABLE/CLEAN at faf317e. Reported to (main). Not merged by me.
- (main) asked: no username in repo. Manager accepts ~/ dependency paths (expanded against self.home) + 2 tests; manifest uses ~/.local/bin/uv; install-engine.sh real home via pwd. Tree grep 0 hits; branch history has 2 in 2509756 → squash merge advised. bd89dbf pushed, #17 MERGEABLE/CLEAN. Reported.
