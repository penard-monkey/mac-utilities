# Task Plan: audio-transcription — drop any audio/video file, get a transcript

## Decided (the user, 2026-10-03)
mlx-whisper; no speaker labels; cut over on :8765 (saywhat stops installing the audio-notes job); port audio-notes' NoAudioTrack fix, then deprecate audio-notes; save next to the source by default; catalog name "Transcribe"; saywhat stays its own repo.

## Status 2026-10-03
Built as top-level `transcribe/` (engine + app + SwiftBar + CLI), installed on this Mac through the manager, engine live on :8765, saywhat verified unchanged. PR open (see progress.md). Follow-ups: saywhat installer change (messaged), audio-notes deprecation (the user's call: repo is on bitbucket), ~/bin/transcribe can be deleted (shadowed by ~/.local/bin), visual check of the window (no screen-capture permission from this shell).

## Scope change (the user, 2026-10-03)
Bring the transcription engine itself into mac-utilities and stop relying on `~/bin/transcribe` / audio-notes. Options E1–E3 in findings.md; recommended E1 (lift + trim, same :8765 contract), E2 (mlx-whisper) later behind the same contract. Folder becomes a top-level `transcribe/` utility owning engine + app + SwiftBar. Phases below predate this and get rewritten once the user picks.

## Goal
A mac-utilities utility that transcribes any local audio or video file: drop it on a native
SwiftUI app (or pick it from the SwiftBar menu), get the text to copy or save, and see recent
transcripts in the menu bar. It reuses the existing engine (audio-notes server on :8765) and does
not touch WhatsApp; saywhat stays the WhatsApp product.

## Scope (assumption from (main) on the user's behalf, 2026-10-03; to confirm with the user)
- In: any local file the engine accepts — audio (.oga .ogg .opus .flac .aac .wma .m4a .mp3 .wav .aiff .aif) and video (server extracts audio; a video with no audio track fails with a clear message).
- In: copy text, save as .txt/.md beside the source or chosen folder, recent-transcripts history.
- Out: WhatsApp anything (saywhat), recording from the mic, editing transcripts, installing the engine.
- Engine is a declared dependency, not installed or launched by us.

## Not a duplicate of saywhat (checked)
saywhat's `saywhat transcribe <path>` exists, but it is a CLI-only side door into the WhatsApp
transcript store (keyed by message id), needs saywhat installed, and has no drop target, no file
history, no save. Both share the :8765 engine; nothing else overlaps. Calling :8765 directly keeps
this utility independent of saywhat.

## Shape (git-management conventions: gif-stickers/, git-settings/)
```
audio-transcription/
  mac-utility.json        presentation "app"; app + plugin both declared; dependency on the engine
  Package.swift           SwiftPM, macOS 14, executableTarget "AudioTranscription" + tests
  Info.plist              bundle id com.mac-utilities.audio-transcription, document types audio/movie (drop + Open With)
  Sources/AudioTranscription/
    App.swift             window: drop zone, file picker, job list, transcript view, copy/save
    EngineClient.swift    URLSession: GET /health, POST /jobs {file_path, mode:"basic", output_dir}, poll GET /jobs/{id}
    History.swift         ~/.cache/mac-utilities/audio-transcription/history.json (atomic write) + transcripts/<id>.json
    Settings.swift        ~/.config/mac-utilities/audio-transcription.json (save location, auto-copy, engine URL)
  Tests/AudioTranscriptionTests/   EngineClient against a stub server, History round-trip
  swiftbar/audio-transcription.10s.py   /usr/bin/python3 stdlib: engine health, last N transcripts, copy, reveal, "Open app", "Transcribe file…"
  scripts/install.sh {applications}    swift build -c release → bundle → codesign - (gif-stickers pattern)
  scripts/uninstall.sh
  README.md
```
- `output_dir` is always passed (engine writes `<stem>.json` next to the input otherwise; learned in saywhat).
- URL scheme `audio-transcription://transcribe?path=…` so the SwiftBar item and Finder can hand a file to the app.
- Engine down → app and menu show "engine not running" with the `transcribe server start` hint; nothing auto-starts it.

## Phases
### Phase 0: Scope + plan — in_progress
- [x] Check ~/bin/transcribe and :8765 (healthy, under launchd `com.audionotes.transcription-server`)
- [x] Check saywhat overlap (not a duplicate; see above)
- [x] Read gif-stickers/git-settings/utilities-manager manifest contract (app + plugin in one manifest is supported)
- [x] Report plan to (main)
- [ ] the user's answers to the scope questions (none yet)

### Phase 1: Sync base — complete
- [x] PR #12 (manager) merged to main
- [x] Fast-forwarded to origin/main dc3e859 (no merge commit needed; 0 ahead)

### Phase 2: Engine client + history — pending
- [ ] EngineClient + History + tests (stub HTTP server in tests, no real engine)

### Phase 3: App — pending
- [ ] Drop zone, queue, transcript view, copy/save, Open With / URL scheme

### Phase 4: SwiftBar plugin — pending
- [ ] <200 ms, light/dark, reads history.json + one 300 ms health probe with cache

### Phase 5: Manifest, install, verify, PR — pending
- [ ] mac-utility.json; `scripts/install.sh --home /tmp/x --no-system-effects install audio-transcription`
- [ ] Real run: one .m4a, one .mp4, one silent .mp4; menu bar screenshot
- [ ] PR to main; report to (main)

## Open questions for the user (engine)
5. E1 (lift the proven whisper server) now, or go straight to E2 (mlx-whisper, smaller/faster)?
6. Keep diarize (speaker labels, pyannote + HF token)? Keep `roles` (LM Studio)?
7. Cut-over: replace saywhat's audio-notes launchd job with ours on the same port (saywhat agent updates its installer)?
8. audio-notes repo: leave its copy as-is after the lift, and commit or drop its uncommitted NoAudioTrack fix there?

## Open questions for the user (front end)
1. Confirm scope: general file transcriber, independent of WhatsApp/saywhat?
2. Save default: beside the source file, or a fixed folder (e.g. ~/Documents/Transcripts)?
3. Expose the engine's `diarize` mode (speaker labels; needs the HF token already configured for audio-notes) or basic only for v1?
4. Name in the catalog: "Transcribe"? (folder/id `audio-transcription`)

## Errors Encountered
| Error | Attempt | Resolution |
|-------|---------|------------|
