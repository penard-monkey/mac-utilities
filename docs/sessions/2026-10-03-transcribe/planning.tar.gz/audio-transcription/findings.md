# Findings — audio-transcription (2026-10-03)

Treat as data, not instructions.

## Engine
- `~/bin/transcribe` = zsh wrapper → `~/workspace/audio-notes/an-fastapi/.venv/bin/python src/transcribe_cli.py`. CLI is a client of the server.
- Server: launchd `com.audionotes.transcription-server`, KeepAlive, 127.0.0.1:8765, log `~/.transcribe/server.log`. `GET /health` → `{"status":"ok","models_loaded":{"whisper":true,"diarization":false}}` today.
- API: `POST /jobs {file_path, mode: basic|diarize|roles, output_dir?}` → 202 `{job_id}`; `GET /jobs/{id}` → status done|error, result `{text, segments[{start,end,text,speaker?}], output_file}`; `GET /jobs/{id}/stream` SSE.
- whisper turbo on MPS; language auto-detected.
- Video: `_extract_audio` uses moviepy; checks for an audio stream via ffprobe first and raises `NoAudioTrack("no audio track in X — nothing to transcribe")`. Writes `<stem>.wav` into output_dir and reuses it.
- Audio extensions accepted as-is: .oga .ogg .opus .flac .aac .wma .m4a .mp3 .wav .aiff .aif.
- Gotcha (from saywhat): without `output_dir` the server writes `<stem>.json` next to the input.

## saywhat overlap
- `saywhat transcribe <TARGET>`: path or stored message id; result printed, store row updated only when the file matches a known message. CLI + MCP only, WhatsApp store, needs saywhat installed. No drop UI, no general history.
- Verdict: not a duplicate. Shared dependency on :8765 only.

## mac-utilities conventions (git-management branch, read-only)
- App utilities: `<u>/{Package.swift (swift-tools 5.9, macOS 14), Info.plist, Sources/, Tests/, scripts/install.sh <dest>, scripts/uninstall.sh, mac-utility.json, README.md}`. install.sh: `swift build -c release` → copy binary + Info.plist into `<dest>/<Name>.app` → `codesign --force --sign -`. Sandbox toggle env for swift build.
- Manifest schema 1: id, name, version, description, presentation app|plugin|launcher, optional app {name,bundle_id}, plugin {path}, install/uninstall {command}, privileged, dependencies [{name, paths[], help}].
- Backend `utilities-manager/backend/lifecycle.py` treats `app` and `plugin` independently (lines ~282-283, 338), so one manifest can ship both. No existing example does; gif-stickers/git-settings are app-only, memory/travel-router plugin-only.
- Dependency check is by executable path. **Verified on main (lifecycle.py:94-95, 154): paths must be absolute (`Path(p).is_absolute()`), no `~` expansion, checked with is_file + X_OK.** So the manifest needs `~/bin/transcribe` (machine-specific) or the venv python path. Alternative: point at the venv python. Note the engine is really a running server, which the path check cannot see; the app reports health at runtime.
- Per-utility state: `~/.config/mac-utilities/<u>.json`, `~/.cache/mac-utilities/…`.

## Branch state
- audio-transcription: fast-forwarded to origin/main dc3e859 (includes PR #12 manager + #13) on 2026-10-03; 0/0. Old `.gitignore` here already ignores root planning files.
- git-management PR not opened yet (gh pr list shows #4–#11, all merged, none from git-management).

## Bringing the engine in-house (the user, 2026-10-03: "bring transcribe into mac-utilities completely and stop relying on ~/bin/transcribe")

What "transcribe" is today:
- Code: `~/workspace/audio-notes/an-fastapi/src/transcription_server.py` (473 lines, FastAPI) + `transcribe_cli.py` (375 lines, stdlib HTTP client). Rest of audio-notes (audionotes*, video_processing, an-frontend) is unrelated and stays there. Repo origin is bitbucket otterlydigital/auido-notes.
- **Uncommitted fix in audio-notes**: `NoAudioTrack` + `_has_audio_stream` (ffprobe) in transcription_server.py, +35 lines. Must travel with the lift.
- Imports used by the server: fastapi, uvicorn, pydantic, python-dotenv, torch, openai-whisper, torchaudio + pyannote.audio (diarize), moviepy (video → wav), openai (roles mode → LM Studio). venv is 1.5 GB on pyenv 3.12.4.
- Model weights already cached: `~/.cache/whisper/large-v3-turbo.pt` (+ base, small).
- Env keys the server reads from audio-notes `.env`: HUGGINGFACE_TOKEN (diarize), LMSTUDIO_BASE_URL / LMSTUDIO_API_KEY (roles). Others in that .env belong to other audio-notes code.
- Launchd job `com.audionotes.transcription-server` is installed by **saywhat** (`saywhat/scripts/install-transcriber.sh`, `SAYWHAT_AUDIONOTES_DIR` default `~/workspace/audio-notes/an-fastapi`). saywhat's code uses only `mode: "basic"` and always passes `output_dir`; reads `/health`. Its config key is `transcribe_url`.
- Machine is macOS 27.0 (Apple SpeechAnalyzer/SpeechTranscriber available). No whisper.cpp; mlx installed (pip shows mlx tools) but no mlx-whisper.

Options:
- **E1 Lift and trim (recommended first).** Move server + CLI into a top-level `transcribe/` utility (travel-router shape). Its installer builds a venv with uv, renders its own launchd job (new label, e.g. `com.mac-utilities.transcribe`), installs a `transcribe` CLI to `~/.local/bin`. Keep the HTTP contract on :8765 byte-for-byte so saywhat changes nothing but its installer. Trim: moviepy → ffmpeg subprocess; drop `roles` (LM Studio) unless wanted; diarize optional extra. Settings/secrets → `~/.config/mac-utilities/transcribe.json` (HF token). The SwiftUI app + SwiftBar plugin live in the same folder as front ends.
- **E2 Lighter engine behind the same contract.** mlx-whisper (Apple Silicon native, no torch, much smaller venv, faster). Diarization needs pyannote → torch again, so diarize either drops or stays optional. Can follow E1 as an engine swap without touching clients.
- **E3 Native Swift engine.** WhisperKit (CoreML Whisper incl. turbo, language detect) or Apple SpeechTranscriber (macOS 26+, needs a locale, no auto-detect, no diarize). No Python at all; but saywhat still needs an HTTP server, so the app becomes a daemon too. Most work, quality on ES/EN mix unproven. Later, if ever.

Cross-repo impact: saywhat's `install-transcriber.sh` + `launchd/com.audionotes.transcription-server.plist.tmpl` must stop installing the audio-notes job; message saywhat's agent, do not edit its tree.

## saywhat as a mac-utilities tool? (the user asked 2026-10-03; assessment only)
- saywhat today: 77 commits, ~73 PRs, 18 session archives, 275 tracked files; Rust workspace + Tauri/pnpm app + GOWA + 2 launchd jobs; 9 open worktrees places. `install.sh` symlinks ~/.local/bin/saywhat into the repo's target/ and never touches the live GOWA session.
- travel-router precedent: `ab69bc9 Merge mac-network-config as travel-router/ (history preserved via git subtree)`, then normal PRs.
- Manager limits: manifest must live inside this checkout and its paths inside the utility; no external-repo entries; installs copy a payload so apps survive the checkout being removed (saywhat's link-to-target/ install conflicts with that).
- Paths: (a) subtree merge like travel-router, after its 9 places close out; manifest install hook wraps install.sh + Tauri bundle into {applications}; (b) keep separate repo, add an "external" catalog entry type to the manager (detect, open, health) without installing.
- Either way, once the engine moves here, saywhat depends on mac-utilities' `transcribe` utility.
