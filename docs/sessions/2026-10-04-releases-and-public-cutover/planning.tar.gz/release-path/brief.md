# Releases, a curl | bash installer, and in-app updates (like worktrees)

## Goal
Today every mac-utilities install is built from a local checkout and "update"
means pointing the manager at a newer checkout. The user wants the worktrees
model: tagged GitHub releases built by CI, a one-line installer, and updates
from inside the app. Then they will remove all local installs and switch over.

Study penard-monkey/worktrees first (~/workspace/worktrees, read-only):
`.github/workflows/release.yml` (tag-triggered, version gate, per-asset
sha256 + checksums.txt, unsigned macOS app bundle), `install.sh`
(SCRIPT_VERSION, WORKTREES_INSTALL_VERSION pin, latest via the
releases/latest redirect with no API or jq, checksum verify, quarantine strip
only on explicit opt-in), and how its app offers Settings → Updates.

## Deliverables
1. **Version + release workflow.** A single repo version (e.g. `VERSION`)
   plus per-utility manifest versions. `.github/workflows/release.yml` on
   `v*` tags, macOS runner: version gate (tag == VERSION == install.sh
   SCRIPT_VERSION), build every app utility (Mac Utilities manager, Git & SSH,
   GIF Stickers, Transcribe once #17 is in, QR Reader when it lands) as zipped
   .app bundles, a catalog archive of the non-app payloads (manifests, SwiftBar
   plugins, engine sources), checksums.txt, release notes. Also a `ci.yml`
   running every test suite on PRs.
2. **Root `install.sh`**, curl | bash, modelled on worktrees': installs the
   manager to ~/Applications and the catalog to the manager's payload store,
   then optionally named utilities (`MAC_UTILITIES_INSTALL=gif-stickers,memory`
   or interactive choice). Pin with `MAC_UTILITIES_INSTALL_VERSION`. Verify
   checksums. Quarantine strip only with explicit opt-in, as worktrees does.
   A local-artifacts mode for testing without GitHub. The repo slug must be a
   single variable: the public repo may end up being a fresh repository.
3. **Updates in the manager.** An Updates view: current vs latest release
   (releases/latest redirect, no API token), update the manager itself
   (download, verify, replace, relaunch) and update installed utilities from
   the release catalog. Keep "choose a checkout" as a developer mode. External
   sources (sources.json, e.g. the private travel-router clone) keep updating
   from their folders. Same in the CLI: `install.sh update [id|--all]`.
4. **Migration off local installs.** A documented, tested path from today's
   checkout-built installs (receipts already exist) to release installs:
   adopt or reinstall without losing settings, SSH keys, Git config, caches or
   TCC grants where avoidable. Report anything that cannot be adopted.
5. **Signing and permissions.** qr-reader found that ad-hoc re-signing changes
   the code hash every build, which may reset privacy grants (Screen
   Recording, Microphone) on every update. Investigate; propose the cheapest
   stable option (e.g. a consistent self-signed identity in CI vs Developer ID
   + notarization) with trade-offs. Do not buy or create real Apple
   certificates; that is the user's decision.
6. **README.** Install section like worktrees' (one-liner, pinning, what goes
   where, how to update, how to uninstall). Utilities table stays.

## Sequencing
Open PRs touch the same areas: #15 manager external sources, #16 travel-router
removal, #17 Transcribe, #18 archive. They await the user's merge. Start from
origin/main with the workflow, installer and version gate; merge origin/main
again once #15 and #17 land, before changing the manager.

## Rules
- Follow AGENTS.md. Commit only on your branch; one PR to main when verified.
  Never merge it.
- No tags, GitHub releases or visibility changes without the user's approval.
  Prove the workflow with workflow_dispatch artifacts or `act`-style local
  runs, and the installer with the local-artifacts mode.
- Do not touch other places (qr-reader, audio-transcription, publish-prep).
- Never uninstall or replace the user's live installs while testing; use an
  isolated home (`--home`) as the existing tests do.
- Planning in gitignored root task_plan.md / findings.md / progress.md.

## When to stop
PR open with the workflow proven on artifacts, installer tested end to end in
local-artifacts mode, Updates working against a fake release feed, migration
documented and tested in an isolated home, and the signing recommendation
written up. Report to (main) via worktrees report. Stop earlier for any
decision only the user can make.
