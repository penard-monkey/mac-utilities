# Findings

- Starting branch release-path and origin/main both at 7e9c841 (utility-manager close-out #14); clean tree.
- Worktrees uses a SCRIPT_VERSION tag gate, releases/latest HTTP redirect, per-asset sha256 and combined checksums. Its app updater separately verifies signed Tauri artifacts.
- Current Mac Utilities bundles a source catalog and Python lifecycle.py; utilities build app bundles via hooks. Receipt ownership is directory hashes and exact symlink targets. Release install must keep those protections.
- #15, #16, #17, #18 are open. Brief forbids manager changes until #15 and #17 land and origin/main is merged.
- No tags/releases authorized. Dispatch workflow must only upload artifacts.
- Foundation implementation packages all nonprivileged catalog entries (private/system router excluded), builds universal arm64/x86_64 apps without invoking live installers, and embeds prebuilt download hooks in release-only manifests. Original utility install scripts/manifests remain checkout developer mode.
- Root installer verifies the bootstrap runtime before execution; the runtime requires checksums for every artifact and rejects archive traversal, duplicate paths, links and special files. Existing Manager/package_app receipts handle publication.
- Local-artifacts mode caches verified app archives in the isolated support store so deleting original test artifacts cannot break subsequent installs.
- Worktrees CLI has no report command in this installed version; use the exposed worktrees MCP report tool.
- Apple TN3127 explicitly ties microphone authorization to designated requirements; ad hoc signatures match only the exact signed program. Recommendation drafted: persistent self-signed identity is cheapest for personal continuity, but needs user approval and real TCC testing; Developer ID+notarization is paid public-distribution option ($99/year per Apple, checked 2026-10-03). No certs created.
- 9 fixture tests pass: local install/update/uninstall, checksum corruption, missing/duplicate hashes, foreign/changed manager protection, stable catalog app install after deleting original artifacts, checkout plugin receipt migration, home-effect guard, unsafe ZIP rejection, tag gate.
- Actual universal archives built successfully for manager, GIF Stickers and Git & SSH; architecture sets and both Mach-O minos 14.0 are checked before codesign/packaging.
- Full current gates pass: release fixture suite, manager 15 Python tests, Tools 5 Python tests, GIF 8 Swift tests, Git & SSH 12 Swift tests, manager build, shell syntax and Python compile checks.
- Added explicit archive quarantine propagation and ditto copying of app bundles, with a test that opts into stripping only on the second update. Downloads are never re-signed by the installer.
- Version gate also refuses publishing from a GitHub repo that differs from the install.sh single REPO setting.
- #15/#16/#17/#18 are merged and incorporated (main ca19892). Updates UI and backend implementation started only after #17 was merged.
- Backend persists immutable release catalogs under support/releases/<tag>/Catalog and selects that stable path in manager preferences; external sources retain folder provenance and update routing.
- Manager Updates checks/installs through the shared release runtime, distinguishes folder sources, offers quarantine opt-in and relaunches only outside no-system-effects mode. Developer checkout controls retained under disclosure.
- Transcribe needs its engine installer after prebuilt app staging; manifest release metadata declares that hook and Apple Silicon engine requirement. Engine hook is suppressed by explicit no-system-effects env propagated from Manager; real installs preserve prior engine/history/settings via the existing engine installer.

Final evidence: all 77 tests and fresh actual four-app artifact install/update proof passed; native fake-feed check/manager update/utility update preserved hidden visibility. PR #19 open. Feature commits 6250ec2 + e10dab3 ready for cleaned-history replay. LICENSE gate independently tested in a fixture; real license remains main cut-over responsibility. Planning retained until post-merge close-out per skill precondition.

macOS system Bash 3.2 under nounset rejects an empty array expansion even when initialized. Use positional $@ for optional args or guarded ${array[@]+"${array[@]}"}. Bootstrap ARGS/PIN, runner Swift options, and release workflow gate all fixed in d41d11a. Hosted macOS CI run <number> passed; regression checks zero args and empty pin.
