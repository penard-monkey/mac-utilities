# Release path

## Goal
Implement the brief's tagged CI releases, verified curl installer, manager Updates, migration, and signing recommendation; open one PR, never merge or tag.

## Phases
1. [complete] Study worktrees; inspect catalog/build/receipt contracts and current main.
2. [complete] Version gate, reusable artifact builder, PR CI and dispatch-only proof; local-artifacts installer with isolated-home tests.
3. [complete] Re-fetch/merge origin/main after PRs #15 and #17 land; then implement manager Updates and fake-feed verification, preserving external sources.
4. [complete] Migration docs/tests, signing research/recommendation, README.
5. [complete] Verify, commit/push/open PR, report to (main). Close-out only as authorized by brief (do not merge).

## Constraints
No user live install mutations, tags/releases/visibility changes, certificates, or edits in other places. Use isolated homes. Repo slug is configured once. Artifacts/scratch live in ~/.cache/worktrees/mac-utilities/release-path (write requires sandbox escalation).

## Dependencies and errors
- 2026-10-03: #15 external sources and #17 Transcribe are OPEN. Manager changes explicitly wait for both merges.
- Initial git fetch sandbox denied despite .git writable root; scoped escalated git fetch succeeded.
- Actual packaging attempt found lipo -verify_arch takes the input before architecture options; fixed. Multi-arch SwiftPM's Xcode build used the host SDK deployment target (27) despite package minimum 14, so builder now compiles explicit arm64/x86_64 macOS14 triples and merges with lipo.
- Full gates: all Python tests and both existing Swift test suites passed, but directory detection mistook utilities-manager/tests for Swift Tests on the case-insensitive filesystem. Changed test discovery to inspect actual Swift test paths; manager gets a build gate instead.
- Installed Xcode lipo rejects even a known universal binary with -verify_arch (same error in both argument orders); replaced that subcommand with -archs set validation and an explicit otool deployment-target gate on both slices. Confirmed individual explicit-triple slices have minos 14.0.
- 2026-10-03 coordinator update: #15/#16/#18 merged; #17 still coming. Public repo will be a cleaned-history fresh penard-monkey/mac-utilities (old private repo archived), MIT LICENSE added at cut-over by main. Keep work commits self-contained for replay.

- #17 merged as ca19892; fetched/merged it before starting manager edits. External source runtime and fake-feed latest checks pass (12 release tests).
- Expanded release migration test caught offline folder probing requiring an installed manager even for a legacy standalone plugin receipt; fixed probe fallback to verified release backend when no manager backend exists.
- CUA native pipe closed after successful Updates tab inspection and fake-feed check button request. Reset/rebind also failed. Replacing remaining manual UI verification with a native ManagerModel integration test invoking the real async process and verified release pipeline (manager + utility updates).

- Hosted macOS CI failed on Bash 3.2 empty-array nounset expansion. Audit all new shell/workflow blocks; verify explicitly with /bin/bash, push, wait for hosted green.
