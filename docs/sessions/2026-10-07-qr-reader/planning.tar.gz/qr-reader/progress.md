# progress — qr-reader

## Session 2026-09-15 — planning

**Done**

- Surveyed the repo: `travel-router/` is the model for the top-level shape;
  `scripts/install.sh` links `*/swiftbar/*.*.*`, so a plugin under
  `qr-reader/swiftbar/` is picked up by the root installer too.
- Probed the machine (results in findings.md): Vision and CIDetector both decode
  a QR with no third-party deps, `swiftc` 6.4 is available via Xcode-beta,
  `/usr/bin/python3` 3.9.6 has no PyObjC, SwiftBar 2.1.1 supports `shortcut=`.
- Generated a QR with `CIQRCodeGenerator` and round-tripped it through both
  decoders — both returned the exact payload.
- Settled the four design questions with the user: top-level + Swift helper,
  prompt-always with no allowlist, redacted history, three input modes.
- Wrote `task_plan.md` (8 phases) and `findings.md`.

**Nothing has been built yet.** No files created under `qr-reader/`; the repo is
still clean on the `qr-reader` branch.

**Next:** Phase 0 spikes — the TCC question is the one that can force a design
change, so it goes first.

**Open questions carried into Phase 0**

- Does `screencapture -i` spawned by SwiftBar need the Screen Recording grant?
- Does an `NSAlert` from a non-bundled CLI binary come to the front reliably?
- Vision or CIDetector as the primary engine, once timed from the built binary?
- Exact `shortcut=` modifier spelling in SwiftBar 2.1.1, and whether it is global.

**Test results**

| What | Result |
|---|---|
| `CIDetector` decode of a generated QR | pass, 0.43 s cold |
| `VNDetectBarcodesRequest` decode of the same | pass, 1.76 s cold |
| `xcrun --find swiftc` | Swift 6.4 (Xcode-beta) |
| `/usr/bin/python3 -c "import objc"` | fail — no PyObjC (expected) |

## Session 2026-10-03 — Phase 0 spikes

New direction from the `(main)` session, on the user's behalf: the front end is
a real bundled SwiftUI app (like `gif-stickers/`, `git-settings/`), not a CLI
helper with an NSAlert, and qr-reader ships a `mac-utility.json` manifest for
the new utilities manager. Both folded into `task_plan.md`; earlier decisions
(prompt always, no allowlist, redacted history, three inputs) stand.

**Done**

- Read the manager contract on the `git-management` worktree:
  `gif-stickers/mac-utility.json`, `git-settings/*` (the build/install template),
  `utilities-manager/README.md`, and `backend/lifecycle.py` to confirm one
  manifest can ship app + plugin. Details in findings.md.
- Built a throwaway spike app (`QRSpike.app`, SwiftPM, ad-hoc signed) that
  generates QR codes, shows them on the real screen, captures the rect and
  decodes it. Nine logged runs.
- Settled 4 of 5 Phase 0 questions. The two that changed the design:
  Screen Recording denial is **silent**, so the app must preflight and prompt
  deliberately; and **Vision is required** because CIDetector cannot tell a
  binary payload from no code.

**Not done / carried**

- Scaffolding. Deliberately blocked: PR #12 (the manager) is open awaiting the
  user's merge, and the plan is to merge `origin/main` first so qr-reader is
  built on the manager rather than retrofitted.
- Three checks deferred to the phase that can actually answer them: grant
  survival across an ad-hoc reinstall (Phase 1), URL-scheme routing from
  `~/Applications` (Phase 6), and interactive proof that the approval window
  never opens without a click (Phase 4).

**Honest note on the spike**

The NSAlert part of the spike was a bad experiment: it put surprise dialogs on
the user's screen while they were actively using the Mac, so the responses it
recorded cannot be attributed to the code. I stopped rather than keep guessing,
and the design now uses a window that provably blocks. Approval behaviour gets
verified with the user driving, not by a script.

**Test results**

| What | Result |
|---|---|
| `CGPreflightScreenCaptureAccess()` (no grant) | false; capture exits 1, "could not create image from rect", no prompt |
| own-window capture without any grant | works (520x520, 1040x520) |
| Vision — one code / two codes / binary | 1 / 2 / payloadData 16 bytes with nil string |
| CIDetector — same three | 1 / 2 / **nil, indistinguishable from no code** |
| Vision timing | 1680 ms cold per process, 16–25 ms warm |
| CIDetector timing | 2–6 ms |
| Vision result order | not reading order — sort by bounding box |
| `NSPanel` + `runModal(for:)` | stayed modal 120 s until killed (correct) |
| `NSAlert.runModal()` | unmeasurable in this harness; see note above |
| `open -g "qrspike://…"` from `/private/tmp` | exit 1, URL never delivered |

**Next:** wait for PR #12 to merge → `git merge origin/main` → Phase 1 scaffold.

## Session 2026-10-03 (continued) — built it

PR #12 merged, so `git merge origin/main` ran first (fast-forward to `dc3e859`)
and everything is built on the manager contract. Committed as `5b0dc2a`,
2486 insertions, on branch `qr-reader`. Nothing touched outside `qr-reader/`
except one row in the root `README.md`.

**Phases 1-6 complete.** Shape: `qr-reader/` with `QRReaderCore` (no AppKit,
29 tests) + `QRReader` app + `swiftbar/qr.1h.py` + `mac-utility.json`, modelled
on `git-settings/`.

**Verified mechanically**

| Check | Result |
|---|---|
| `swift test` | 29 tests, 0 failures |
| manifest against the real `lifecycle.validate` | passes |
| managed install into an isolated home | app in `Applications`, plugin symlinked out of the payload, receipt covers both |
| real install via `scripts/install.sh install qr-reader` | `~/Applications/QR Reader.app`, ad-hoc signed, id `com.macutilities.qr-reader` |
| plugin output | correct in both branches (app missing / app installed), icon-only title |
| `open -g -b com.macutilities.qr-reader --args --scan=clipboard` | exit 0 from the installed location |

**Three things the build taught me** (all now in code comments, the README and
findings.md): Vision is required rather than merely nicer; Foundation rewrites
URLs as it parses, so the window has to disclose when the opened string differs
from the scanned one; and a colon does not make a scheme.

**Not yet verified — needs the user, by design**

Every user-facing path is modal, which is the point, so it cannot be proven by
script. Waiting on interactive confirmation of: the approval window appearing
and *waiting*; Cancel / Escape / window-close all ending in no action; the
region scan and its Screen Recording prompt; and whether the grant survives a
reinstall (the open Phase 0 question — ad-hoc signing changes the cdhash every
build).

Test codes for that pass are in `_tmp/qr-reader-tests/` (10 payloads: plain,
userinfo phish, punycode, shortener, OTP seed, javascript, Wi-Fi, custom
scheme, prose with a colon, cleartext IP).

**Next:** interactive verification → fix whatever it finds → PR to `main` →
report to `(main)`.

## Session 2026-10-03 (continued) — rebased onto the new main

Asked by `(main)` to rebase so the public-repo cut-over's replay check is not
blocked. Done, frozen, not pushed, no PR.

- `git rebase origin/main` over 6 commits (travel-router removed #16, external
  catalogs #15, Transcribe #17, releases/installer/updates #19).
  **No conflict** — git auto-merged the root README table, so I checked it by
  hand rather than trusting it: Travel Router row gone, Transcribe row present,
  my QR Reader row sits right after GIF Stickers, as instructed.
- New HEAD `1c7c34a`, one commit on top of `fcf002e`. Nothing else of mine changed.
- Re-verified after the rebase: 29 tests pass; the manifest still validates
  against the current `lifecycle.validate`.
- Checked #19's release packaging (Phase 8 in task_plan.md). No code needed:
  manifests are auto-discovered, icons are generic via `make-icon.swift`, and I
  confirmed both arch slices build at `minos 14.0`, which is the gate build.py
  enforces. Only `release.yml`'s hardcoded `MAC_UTILITIES_INSTALL` list needs
  `qr-reader` added — left alone, flagged to `(main)`.

**Still outstanding and unchanged:** the interactive verification. The approval
window was put on screen for the user (clipboard decode of the userinfo-phish
test code) and they have not reported back yet. Region scan, the Screen
Recording prompt, and grant survival across a reinstall remain unproven.

## Session 2026-10-07 — shipped in PR #16 (release 1.5.0)

Rebased onto the public repo, finished the release integration, and opened
https://github.com/penard-monkey/mac-utilities/pull/16 — CI green in 4m13s.
Two commits: the utility, then the icon + release integration + fixes.

**Interactive verification, cut short by the user's call.** They chose to
exercise region scanning live after the release rather than keep testing a dev
build. What that pass did establish before stopping:

- The approval window **waits**: shown 22:40:23Z, denied 22:44:35Z — 252
  seconds untouched, then `cancelled`, nothing opened. The core property now
  has evidence, not an argument.
- The Oct-3 `"decision": "opened"` entry was the user clicking Open themselves.
  Not a bug. Worth remembering as a lesson: I nearly chased a phantom because I
  read an ambiguous artifact as a failure.
- Clipboard input, the risk flag, redaction on disk, and the Screen Recording
  prompt all work.
- One region-scan drag returned "No code found" with the grant present and a
  file written. **Cause still unknown** — in ROADMAP.md, not papered over.

**Three real fixes, none found by a failing test**

1. `payloadData` is macOS 14.0, not 15 — my guard would have broken binary
   payloads on the minimum supported OS.
2. Approval window key handling: Cancel was default-button-cell *and* Escape,
   with no pinned focus, so a stray Space could press Open. Now Cancel owns
   Return, DenyingPanel owns Escape, focus starts on deny.
3. `screencapture`'s "could not create image from display" was reaching the
   user as a raw error. It is a permission failure and now routes to the
   permission window — the path every user hits after every update.

**Measured, not inferred:** rebuilding the app with nothing else changed, same
bundle id and path, revoked a working Screen Recording grant. signing.md said
this was an inference from Apple's identity model; it is now an observation.

**My own misstep, recorded so it is not repeated:** I rebuilt the dev app while
the user held a grant on it, which silently revoked their permission and threw
raw "status 1" popups at them. Diagnostics must be complete *before* asking
someone to grant anything.

**Cleanup done:** diagnostics stripped (decision 6 holds — captures are deleted
immediately), dev app removed, its TCC entry reset via a stub bundle because
tccutil cannot resolve a deleted app, LaunchServices unregistered, the real
app's history restored and the dev app's stale state file removed.

**Next:** nothing. Do not merge, tag or release — that is the user's call.
