# task_plan — qr-reader

## Goal

Capture a screen region containing a QR code, decode it, and **show exactly what
it is about to do and wait for approval before doing it**. The approval step is
the product; decoding is the easy part.

Front end is a real bundled SwiftUI app plus a SwiftBar menu bar item. Ships as
a managed utility with a `mac-utility.json` manifest. Branch `qr-reader`,
worktree `.worktrees/qr-reader`, PR to `main`. Never commit on `main`.

## Decisions (settled; do not relitigate)

1. **Bundled app + plugin.** `QR Reader.app` (SwiftPM, ad-hoc signed, installed
   to `~/Applications`) is where capture, approval and history live. The
   SwiftBar item is a thin trigger. Phase 0 confirmed the TCC grant attaches to
   the app bundle, which is the right identity for the user to see.
2. **Prompt every time. No allowlist, no "always trust", no suppression.**
3. **History on, redacted** (`~/.cache/mac-utilities/qr-reader-history.jsonl`,
   mode 600, cap 100, secrets stripped at write time).
4. **Inputs:** drag-a-region, clipboard image, image file. No whole-screen scan.
5. **Never** open `otpauth:`, `javascript:`, `data:`, `file:`. Unknown custom
   schemes are copy-only behind a second confirmation.
6. Captured images are deleted immediately after decoding.
7. **Vision, not CIDetector**, as the decoder — only Vision distinguishes a
   binary payload from no code (Phase 0). Warm it at launch; CIDetector is the
   fallback second opinion.
8. **The approval UI is an explicit window, not `NSAlert`** (Phase 0: NSAlert
   behaviour was unmeasurable in an automated harness; a panel provably waits).
   Open is reachable only through a button action.
9. **One manifest ships both** the app and the plugin — the manager handles
   `app` and `plugin` independently of `presentation`.

## Layout

```
qr-reader/
  Package.swift                  QRReaderCore (testable) + QRReader (app)
  Info.plist                     bundle id com.macutilities.qr-reader, URL scheme
  mac-utility.json               presentation "app" + app{} + plugin{}
  Sources/QRReaderCore/          Classifier.swift, Risk.swift, History.swift, Payload.swift
  Sources/QRReader/              App.swift, CaptureService.swift, ApprovalWindow.swift
  Tests/QRReaderCoreTests/       the payload → verdict table
  swiftbar/qr.1h.sh              menu bar trigger
  scripts/install.sh             build, assemble, ad-hoc sign, place in {applications}
  scripts/uninstall.sh
  .gitignore                     .build/ .swiftpm/
  README.md
```

Modelled on `git-settings/` (Core library + app target, same install/uninstall
shape, same bundle-id verification before replacing anything).

## Phases

| # | Phase | Status |
|---|---|---|
| 0 | Spikes: TCC, approval window, engine, trigger | **complete** |
| 1 | Merge `origin/main`, scaffold | **complete** |
| 2 | Capture + decode core | **complete** |
| 3 | Classifier + risk engine (+ unit tests) | **complete** |
| 4 | Approval window and actions | **complete** |
| 5 | History, redaction, settings | **complete** |
| 6 | SwiftBar plugin + manifest | **complete** |
| 7 | README, verification, PR | **complete** — PR #16, CI green |

### Phase 0 — complete

Answered: TCC fails **silently** when denied (`CGPreflightScreenCaptureAccess()`
is the check, `CGRequestScreenCaptureAccess()` the only reliable prompt); Vision
is required for binary payloads and must be warmed; Vision result order is not
reading order; the manager installs app + plugin from one manifest and symlinks
the plugin out of its own payload directory. Deferred to later phases: whether
the Screen Recording grant survives an ad-hoc reinstall (Phase 1), whether the
URL scheme routes once installed in `~/Applications` (Phase 6), and interactive
confirmation that the approval window never opens without a click (Phase 4).

### Phase 1 — Merge, then scaffold

**Do not scaffold before `origin/main` has the manager.** PR #12 (branch
`git-management`) is open awaiting the user's merge. Then:
`git fetch origin && git merge origin/main`, and build on the manager contract.

Scaffold: `Package.swift` (QRReaderCore + QRReader + test target),
`Info.plist`, `.gitignore`, `scripts/install.sh` + `uninstall.sh` copied in
spirit from `git-settings/`, a window that does nothing yet.

Then the deferred TCC test: install, grant Screen Recording, reinstall, and
check whether the grant survived. Record the answer in findings.md and in the
README.

### Phase 2 — Capture + decode

`CaptureService`: region (`screencapture -i -s -x` into a 0700 `mktemp -d`,
`defer`-deleted), clipboard (`NSPasteboard`, no temp file), file (reject
non-images). Escape during selection = silent no-op. Preflight TCC before
offering region capture.

`Decoder`: Vision primary with a warmed request, CIDetector fallback, results
sorted by bounding box. Binary payloads surface as "binary, N bytes", never as
"no code found".

### Phase 3 — Classifier + risk engine

Pure functions in `QRReaderCore`: `payload → {type, fields, flags, openable}`.
Types and risk checks are tabulated in findings.md. Unit-tested as a table of
payload → expected verdict (`swift test`), which is the piece most worth
testing and the easiest to get subtly wrong.

### Phase 4 — Approval window

Explicit window. Payload monospaced and middle-truncated with the **registrable
domain highlighted** and punycode shown decoded; risk flags as a bullet list;
caution styling when any flag is set. Cancel is the default and Escape maps to
it; closing the window is a deny. No timeout ever auto-accepts. "Resolve
redirects…" is an explicit, labelled network action. **The string shown is the
string opened** — no re-parsing between display and `NSWorkspace.open`.

Verify interactively with the user: a code that must not open without a click,
Escape, and window-close all end in no action.

### Phase 5 — History, redaction, settings

As decided: jsonl, 600, cap 100, redact `WIFI:` passwords, `otpauth` secrets,
URL userinfo and password-ish query params. Settings in
`~/.config/mac-utilities/qr-reader.json`, written only when changed.

### Phase 6 — Plugin + manifest

`swiftbar/qr.1h.sh`: `sfimage=qrcode.viewfinder`, items for Scan region
(`shortcut=`), Decode clipboard, Decode file…, recents (redacted), and a
"Grant Screen Recording" line when preflight fails. Renders from state only,
never decodes, well under 200 ms, adapts to `OS_APPEARANCE`, and reaches the app
by bundle id / URL scheme — **never a repo-relative path**, since the installed
plugin is a symlink inside the manager's payload directory.

Manifest: `presentation: "app"`, `app {name: "QR Reader.app", bundle_id:
"com.macutilities.qr-reader"}`, `plugin {path: "swiftbar/qr.1h.sh"}`,
`install`/`uninstall` commands, `privileged: false`, no dependencies. Both
`app.name` and `plugin.path` are frozen once released, so get them right now.

### Phase 7 — Docs, verification, ship

README (what it does, the security model and what it deliberately refuses, the
Screen Recording requirement, options, verification). Root README row. Verify
per CLAUDE.md. PR to `main`; report to the `(main)` session when it is open.

### Phase 8 — Shipping as a release app (#19), for later

Checked against `scripts/release/build.py` on current `origin/main`. qr-reader
needs **no code changes** to ship as a release app:

- `build.py` auto-discovers `*/mac-utility.json` and skips `privileged: true`,
  so qr-reader is picked up with no list to join.
- It assembles the bundle itself and replaces the manifest's install command
  with `scripts/release-install.sh`, so `qr-reader/scripts/install.sh` serves
  only the source/manager path. Both stay.
- Icons are generic: it runs `<utility>/scripts/make-icon.swift` when present.
  Verified it works headlessly and `iconutil` accepts the set (83 KB .icns).
- Verified the release gates directly: both `arm64` and `x86_64` slices build
  at `--triple …-apple-macosx14.0`, `lipo -archs` gives both, and `otool`
  reports `minos 14.0` in both — which is what build.py refuses to ship
  without. `payloadData` turned out to be `API_AVAILABLE(macos(14.0))`, not 15 —
  the availability guard I first wrote would have silently disabled binary
  payloads on macOS 14, and is gone.

**The one thing outstanding:** `.github/workflows/release.yml` has a hardcoded
`MAC_UTILITIES_INSTALL: memory,git-settings,gif-stickers,transcribe`.
`qr-reader` has to be added there to be covered by the release smoke test.
Deliberately not changed here — it is a shared release file owned by another
work stream, and this branch is frozen. Flagged to `(main)`.

## Non-goals

QR generation, camera capture, joining Wi-Fi automatically, a trust allowlist,
"open in a specific browser", whole-screen scan.

## Errors Encountered

| Error | Attempt | Resolution |
|---|---|---|
| `screencapture` → "could not create image from rect", exit 1, no file | 1 | Not a bug: Screen Recording denied. `CGPreflightScreenCaptureAccess()` false. Design now preflights and prompts deliberately. |
| `NSAlert.runModal()` returned a button instantly, no click | 1 | Ran it before the app's run loop existed (synchronously in `main`). Moved into `applicationDidFinishLaunching`. |
| …still returned varying buttons at 0 ms / 805 ms / 5746 ms | 2 | Harness was contaminated — the user was clicking live. Stopped trying to prove it automatically; switched to a panel (which provably blocks) and deferred the check to interactive Phase 4 verification. |
| Auto-dismiss timer never fired inside the modal | 1 | `Timer` in `.default` mode does not fire during a modal session; `.modalPanel`/`.common` is required. Noted for any future timeout logic. |
| `open -g "qrspike://…"` exit 1, URL never delivered | 1 | Unresolved. Likely LaunchServices ignoring an app under `/private/tmp`; re-test from `~/Applications` in Phase 6, three fallbacks listed in findings.md. |
