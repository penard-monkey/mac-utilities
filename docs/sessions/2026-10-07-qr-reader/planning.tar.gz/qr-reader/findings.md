# findings — qr-reader

Research notes. Everything here was verified on this Mac (macOS 26 / Darwin 27,
Apple silicon, SwiftBar 2.1.1) unless marked UNVERIFIED.

## Decode engines (both work with zero third-party deps)

Tested by generating a QR with `CIQRCodeGenerator` and decoding it back.

| Engine | Result | Time (cold) | Notes |
|---|---|---|---|
| `CIDetector(CIDetectorTypeQRCode)` | `["https://example.com/test?a=1"]` | 0.43 s | QR only. `messageString` is a String — no access to raw bytes. |
| `Vision VNDetectBarcodesRequest` | `[["VNBarcodeSymbologyQR","https://example.com/test?a=1"]]` | 1.76 s | All symbologies (QR, Aztec, DataMatrix, PDF417, Code128…). `payloadStringValue` is nil for binary payloads; `payloadData` gives bytes (API_AVAILABLE macos 14.0 — verified in the 14.4 SDK, so no availability guard is needed). |

Both are reachable from `osascript -l JavaScript` (ObjC bridge) *and* from Swift.
Scratch scripts used for the test: `gen.js`, `dec.js`, `dec2.js` in the session
scratchpad.

**Choice: Vision, with CIDetector as a fallback** if Vision returns nothing.
Vision's extra symbologies are free, and the 1.7 s was a cold model load in a
fresh `osascript` process — from a resident-ish Swift binary it is well under
that, and the scan is user-initiated so a beat is acceptable. Decide finally in
Phase 0 by timing both from the compiled binary.

**Trap:** `payloadStringValue` is nil for a binary/non-UTF8 payload. Do not treat
nil as "no code found" — surface it as "binary payload, N bytes, cannot open".

## Toolchain

- `swiftc` present: Apple Swift 6.4, via **Xcode-beta.app** (`xcrun --find swiftc`
  → `/Applications/Xcode-beta.app/...`). `install.sh` must call `xcrun swiftc`
  (not a hardcoded path) and fail with a clear message if no toolchain exists.
- `/usr/bin/python3` is 3.9.6 with **no PyObjC** (`import objc` → ModuleNotFoundError).
  So a pure-Python plugin cannot decode by itself; it would have to shell out.
  This is the main reason the utility is not a single Python plugin.

## SwiftBar 2.1.1

- `PluginDirectory = ~/.swiftbar`, `MakePluginExecutable = 1`.
- Binary strings confirm a **`shortcut`** parameter alongside `bash`, `refresh`,
  `terminal`, `WebView`. So a menu line can carry a *global* hotkey:
  `Scan region… | shortcut=CMD+SHIFT+9 bash=/usr/local/bin/qr-scan param1=capture terminal=false`.
  UNVERIFIED: exact spelling of modifiers and whether the hotkey is global or
  menu-only — confirm in Phase 0 against SwiftBar docs and by trying it.
- `open -g "swiftbar://refreshplugin?name=qr"` re-renders the plugin; the helper
  should call this after a scan so the recents list updates.

## screencapture

`screencapture [-icMPmwsWxSCUtoa] [files]`, relevant flags:

- `-i` interactive selection (esc cancels, space toggles window mode, ctrl → clipboard)
- `-s` selection mode only (no window mode) — what we want for "drag a region"
- `-x` no sound, `-J selection` start style, `-U` interactive toolbar (we do *not* want it)
- `-R x,y,w,h` non-interactive rect, `-D<n>` a specific display, `-t<fmt>` format
- `-c` straight to clipboard
- Exit status is non-zero / no file written when the user hits escape — that is
  the "user cancelled" path and must be silent.

**Open risk (Phase 0 blocker): TCC.** On modern macOS `screencapture` is
attributed to the *responsible process*, which here is SwiftBar.app. UNVERIFIED
whether `-i` specifically requires the Screen Recording grant. Three outcomes:

1. Works with no grant → nothing to do.
2. Needs the grant → SwiftBar.app gets Screen Recording once in System Settings;
   the plugin detects the failure and shows a "Grant Screen Recording to
   SwiftBar" line with a `x-apple.systempreferences:` deep link.
3. Attribution lands on our rebuilt binary → the grant resets on every rebuild
   (ad-hoc cdhash changes). Then fall back to the clipboard flow (⌃⇧⌘4 then
   "Decode clipboard"), which needs no permission at all.

The clipboard input is worth having regardless, for exactly this reason.

## CLI NSAlert gotchas (UNVERIFIED, expect to hit these)

A non-bundled CLI binary that shows an `NSAlert` needs, on the main thread:
`NSApplication.shared.setActivationPolicy(.accessory)` then
`NSApp.activate(ignoringOtherApps: true)` before `runModal()`, or the window
appears behind everything and never takes key focus. If `.accessory` misbehaves
when launched from SwiftBar, the fallbacks are `.regular` (shows a Dock icon for
the life of the alert) or wrapping the helper in a minimal `.app` bundle.

## Payload types worth handling

| Prefix | Type | Default action |
|---|---|---|
| `https://` | web link | approve → open |
| `http://` | insecure web link | approve → open, flagged (cleartext) |
| `mailto:` `tel:` `sms:` `facetime:` | contact | approve → open |
| `geo:` `maps:` | location | approve → open |
| `WIFI:S:…;T:WPA;P:…;;` | Wi-Fi join | show SSID + reveal-on-click password; never auto-join in v1 |
| `otpauth://` | **TOTP/HOTP seed** | never open (would silently add an authenticator entry); copy only, loud warning |
| `BEGIN:VCARD` / `MECARD:` | contact card | show fields; copy only in v1 |
| `javascript:` `data:` `file:` | dangerous | never open, copy only |
| anything else (custom scheme) | app handoff | copy by default; "Open anyway" behind a second confirmation, since a custom scheme can hand a payload straight to a local app |
| non-UTF8 | binary | show byte count + hex head; copy only |

## URL risk checks for the approval window

Cheap, local, no network:

- **Punycode / IDN homograph** — decode `xn--` labels, show the Unicode form next
  to the ASCII form, flag mixed scripts within one label (Cyrillic а in a Latin word).
- **Embedded credentials** — `https://apple.com@evil.tld/` is the classic QR
  phish; the registrable domain is `evil.tld`. Highlight the true host, flag the userinfo.
- **Look-alike characters** in the registrable domain (`paypa1`, `rn` vs `m`).
- **Shortener** — host in a small known list (bit.ly, t.co, tinyurl, is.gd, …) → say so.
- **Cleartext http**, non-standard port, raw IP host, overlong URL, `%00`,
  RTL-override / zero-width characters anywhere in the string.
- **Scheme** not in the openable allowlist.

Network, and only on an explicit click (the button must say it contacts the site):
**Resolve redirects** — ephemeral `URLSession` (no cookies, no credential store),
HEAD with a GET+`Range: bytes=0-0` fallback, 5 s timeout, max ~10 hops, show the
full chain and the final host.

## Conventions this utility must follow (from CLAUDE.md)

- Top-level `qr-reader/`, plugin at `qr-reader/swiftbar/<name>.<interval>.<ext>`,
  own `scripts/install.sh` that does its system side and links its own plugin.
- Settings: `~/.config/mac-utilities/qr-reader.json`.
  Regenerable state: `~/.cache/mac-utilities/qr-reader-history.jsonl`.
- Menu bar item adapts to light/dark (`OS_APPEARANCE`) and stays well under 200 ms
  per render — so the plugin must never decode anything itself, only read state.
- Plugin must not rely on the user's PATH; call `/usr/local/bin/qr-scan` absolutely.
- Short `README.md` describing what it shows, how it works, and its options.

## Deferred / explicitly out of scope for v1

- Whole-screen / all-displays scan (not chosen; easy to add later as a mode).
- Trust allowlist ("always trust this domain") — deliberately rejected, the
  prompt is unconditional.
- Camera capture, QR *generation*, joining Wi-Fi networks directly,
  "open in a specific browser / private window".

---

# Phase 0 results — 2026-10-03

Spiked with a throwaway bundled app (`QRSpike.app`, SwiftPM + ad-hoc signed,
built in the session scratchpad) that generated QR codes, put them on the real
screen in its own window, captured that rect, and decoded it. Raw logs:
`scratchpad/spike{1..9}.log`.

## 1. Screen Recording / TCC — ANSWERED, and it fails silently

With no grant (the state the Mac is actually in — the user did not add the spike):

- `CGPreflightScreenCaptureAccess()` → **false**
- `screencapture -x -r -R <rect> out.png` → **exit 1**, stderr
  `could not create image from rect`, no file written
- a full-screen `screencapture` (no `-R`) → exit 1, `could not create image from display`
- **no TCC prompt from `screencapture` itself.** A prompt did appear to the user
  at some point during repeated attempts, but it is not reliable and not
  synchronous with the failure.

So the failure mode is a silent nothing: the user drags a selection and no code
ever appears. That is unacceptable, and it drives the design:

- Preflight with `CGPreflightScreenCaptureAccess()` **before** offering capture.
- Raise the prompt deliberately with `CGRequestScreenCaptureAccess()` — that is
  the only call that reliably shows it.
- If still denied, show our own explanation with a deep link to
  `x-apple.systempreferences:com.apple.preference.security?Privacy_ScreenCapture`
  and point at the clipboard flow, which needs no permission.
- The SwiftBar item must surface the un-granted state rather than look idle.

The grant attaches to the **app bundle**, which is the right place — the user
sees "QR Reader" in Settings, not "SwiftBar" or "python3".

**Still open:** the installer re-signs ad hoc on every build, so the cdhash
changes on every reinstall. Whether the Screen Recording grant survives an
update is untested (the spike was rebuilt between the prompt and the retest,
which may be exactly why the grant never took). Phase 1 must test: install,
grant, reinstall, check `CGPreflightScreenCaptureAccess()` again. If the grant
resets, the README has to say so and the app must detect it.

**Bonus finding:** `CGWindowListCreateImage(.null, .optionIncludingWindow, …)`
on **our own** window works with no grant at all (produced 520x520 and
1040x520 images). Useless for scanning other apps, but it means an in-app
"re-show this code" view needs no permission.

## 2. Approval window — PARTIAL, but decided

- `NSPanel` + `NSApp.runModal(for:)` **provably waits**: one run sat modal for
  the full 120 s until it was killed. That is the behaviour a security prompt
  needs.
- `NSAlert.runModal()` measurements are **contaminated and must not be trusted**:
  across runs it returned `alertFirstButtonReturn`, then `…SecondButton`, then
  `…ThirdButton` with elapsed times of ~0 ms, 805 ms and 5746 ms. The user was
  actively clicking around their Mac at the time (hunting for the Screen
  Recording toggle), and surprise dialogs almost certainly got clicked. The
  varying button *and* the human-scale latencies both point that way.
- Also learned, and it matters for any auto-dismiss or timeout logic: **a
  `Timer` scheduled in `.default` mode never fires during a modal session.**
  `DispatchQueue.main.asyncAfter` did not visibly fire inside `runModal` either
  in this harness.

**Decision:** build the approval as an explicit window (SwiftUI/NSPanel) whose
only route to Open is a button action, not `NSAlert`. It is what the rich UI
needs anyway (highlighted registrable domain, risk badges, disclosure, redirect
resolver), and it is the variant that demonstrably blocks. Its "never opens
without a click" property gets verified **interactively with the user** in
Phase 4 — not in an automated spike, which is what went wrong here.

## 3. Decode engine — ANSWERED, Vision wins on correctness

Decoding real captured screen pixels (not a synthetic file):

| Case | Vision | CIDetector |
|---|---|---|
| one URL code | 1 result, correct | 1 result, correct |
| two codes in one capture | 2 results, both correct | 2 results, both correct |
| binary payload (`FF FE 00 01 80 7F`) | `payloadStringValue` nil, **`payloadData` = 16 bytes** | `messageString` nil — indistinguishable from "no code" |
| cold first call in a process | 1680 ms | 4–6 ms |
| warm | 16–25 ms | 2–6 ms |

- **Vision is required**: only it can tell a binary payload from no code at all,
  via `payloadData`. CIDetector reports `nil` for both.
- The 1.7 s is a one-time model load per process → **warm a throwaway
  `VNDetectBarcodesRequest` at app launch** so the first real scan is ~20 ms.
- CIDetector stays as a cheap second opinion when Vision returns nothing.
- **Vision results are not in reading order** — the two-code case returned
  `second.example/b` before `first.example/a`. The multi-code picker must sort
  by bounding box, never trust array order.

## 4. Plugin → app trigger — UNRESOLVED

`open -g "qrspike://scan?source=region"` returned **exit 1** and the running app
never got `application(_:open:)`, despite `CFBundleURLTypes` in Info.plist. Most
likely LaunchServices does not register an app living under `/private/tmp`.
Re-test once the app is installed to `~/Applications`. Fallbacks, in order:

1. custom URL scheme (preferred — routes into the running instance, so the
   capture happens under the app's TCC identity)
2. `open -g -a "QR Reader.app" --args --scan=region` — note `--args` is **not**
   delivered to an already-running instance, so pair it with
   `applicationShouldHandleReopen` meaning "scan region"
3. a command file the app watches under `~/.cache/mac-utilities/`

## 5. Manager integration — ANSWERED by reading the contract

From `utilities-manager/backend/lifecycle.py` on `origin/git-management`:

- `app` and `plugin` are validated and installed **independently of
  `presentation`** (lines 81, 278, 283) — so one manifest can ship the app *and*
  the SwiftBar plugin. No existing utility does both; qr-reader is the first.
- The installed plugin is a **symlink into
  `~/Library/Application Support/mac-utilities/payloads/qr-reader/swiftbar/…`**,
  not into the worktree. The plugin therefore must not use repo-relative paths;
  it should reach the app by bundle id / URL scheme, or at
  `~/Applications/QR Reader.app`.
- Install hooks run with `cwd` = the payload copy, `PATH=/usr/bin:/bin:/usr/sbin:/sbin`,
  and `HOME` set by the manager. Use `/usr/bin/swift` (house style, and `xcrun`
  would resolve to Xcode-beta here).
- Plugin filenames must match `.+\.[0-9]+[smhd]\.[^.]+` → `qr.1h.sh` is valid.
- Changing `app.name` or `plugin.path` after release forces a manual uninstall
  ("Presentation paths changed"), so both are effectively frozen at first install.
- `app` + non-privileged requires an `install` command; `{applications}` is an
  isolated staging dir and the installer must produce exactly the named bundle
  there.
