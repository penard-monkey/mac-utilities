# Spike: can an ad-hoc-signed Quick Look extension with VLCKit load and play MKV/WebM?

Use the planning-with-files skill: keep task_plan.md, findings.md and
progress.md at this worktree's root (gitignored) current throughout.

## Context
The user wants a mac-utilities utility (working name "Video Preview", id
`video-preview`) that makes Finder's spacebar Quick Look PLAY .mkv and .webm
with sound, built on VideoLAN's official VLCKit. We are NOT forking QLCodec
(github.com/Oil3/QLCodec): its custom license grants no right to modify or
redistribute its code. You may read it for orientation only; write our own code.
Releases are built in CI and installed by our curl installer and the Mac
Utilities manager; every app is only ad-hoc signed (`codesign --sign -`), no
Apple Developer ID. See docs/releases/README.md and docs/releases/signing.md.

## The question this spike answers (go / no-go)
Will macOS load and run a Quick Look PREVIEW extension (.appex inside a small
host app) that is ad-hoc signed, embeds VLCKit, and is installed the way our
installer installs apps (downloaded with curl, no quarantine attribute, placed
in ~/Applications, host app launched once)? And does it play video with audio
inside the Quick Look panel?

## What to build (minimum, throwaway quality is fine)
- An Xcode project (SwiftPM cannot build app extensions) with a host app and a
  Quick Look Preview Extension (QLPreviewingController / NSViewController,
  view-based preview) registered for MKV and WebM UTIs (org.matroska.mkv,
  org.webmproject.webm; check the declared UTIs on this Mac and declare
  imported types if needed).
- VLCKit for macOS from VideoLAN's official download (stable 3.x, not the 4.x
  beta), downloaded by a script that pins the exact URL and SHA-256 and fails
  on mismatch. Never commit the framework binary.
- The extension plays the file with VLCKit's player in its view, with sound,
  looping, inside the App Sandbox (required for extensions). Note any
  entitlements VLCKit needs (e.g. read access to the previewed file is given by
  Quick Look; network must stay off).
- Build with xcodebuild from the command line, then ad-hoc sign: the framework,
  the appex, then the app (inside-out), with the entitlements.

## Experiments to run and record in findings.md
1. Install the built app as "Video Preview Spike.app" in ~/Applications,
   launch it once, then check: `pluginkit -mAvvv -p com.apple.quicklook.preview`
   shows the extension enabled; `qlmanage -r` and `qlmanage -p <file>` on a
   sample MKV and WebM you generate locally with ffmpeg (VP9/Opus WebM, H.264 or
   VP9 MKV; no personal media).
2. Watch `log stream --predicate 'subsystem CONTAINS "quicklook" OR process
   CONTAINS "Spike"' --level debug` while previewing; record any sandbox,
   code-signing or library-validation denials (e.g. VLCKit's embedded plugins
   failing to load under library validation).
3. Repeat with the app zipped, downloaded via `curl` from a local HTTP server
   (mirrors the installer: no quarantine), and once WITH quarantine
   (`xattr -w com.apple.quarantine ...`) to document what a browser download
   would do.
4. If ad-hoc fails, try in order and record each: disabling library
   validation via entitlement (com.apple.security.cs.disable-library-validation)
   on the appex; a local self-signed code-signing certificate created for the
   spike (do not touch the user's existing keychain items; create a separate
   temporary keychain). Do NOT obtain or use any Apple Developer certificate.
5. Note size of the VLCKit framework and of the zipped app, and whether the
   build works on the macos-14 GitHub runner's Xcode (check `xcodebuild
   -version` there via a workflow_dispatch-free reasoning from
   .github/workflows; do not push workflows in this spike).

## Visual check
You may not use Computer Use. When the extension is registered and logs look
clean, stop and send a worktrees report to (main) asking the user to press
space on the two sample files (give their paths) and tell us whether they play
with sound. Wait for the answer before concluding.

## Deliverable
findings.md with a clear GO / NO-GO, the exact signing recipe that works,
entitlements, VLCKit version + SHA-256, sizes, and what the real utility needs
(release builder changes, manifest, installer). Commit the spike's project and
scripts on this branch (no binaries, no VLCKit, no sample media) and push the
branch, but do NOT open a PR. Report to (main) when done.

## Rules
- Follow AGENTS.md (incl. /bin/bash 3.2). Public repo: no personal data.
- Never touch the user's installed mac-utilities apps, receipts or
  ~/.swiftbar. The only things you may install are "Video Preview Spike.app"
  in ~/Applications and a temporary keychain; remove both at the end and say so.
- No Computer Use. No merges, tags or releases.
