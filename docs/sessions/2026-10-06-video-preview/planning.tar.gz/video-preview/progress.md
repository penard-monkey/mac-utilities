# Progress

## 2026-10-06 utility phase
- Switched place to branch video-preview off origin/main (edf25cb).

## Spike log
## 2026-10-06
- Read brief; Xcode 27.0 (27A266a), macOS 27.0, ffmpeg present, no xcodegen.
- VLCKit 3.7.3 pinned (sha 019afdae...). fetch-vlckit.sh verified.
- Hand-written xcodeproj builds universal; build.sh signs inside-out ad hoc.
- Exp1 OK after switching from VLCMediaListPlayer to VLCMediaPlayer; loop via delegate.
- Exp3: framework symlinks refused by build.py/install.py; LAYOUT=dylib passes and plays.
- Exp3 quarantine: GK prompt + translocation, extension not registered.
- Next: install dylib build via installer path, report to main for visual/audio check, wait.
- 16:12 Reported to (main) (msg <number>-7173-00000000); waiting for user's Space-bar check. Spike README written; nothing committed yet.
- User verified via (main): both play in QL panel, tone audible, both loop. GO written in findings.md.
- Committed 200df97 on video-preview-spike, pushed to origin (no PR).
- Cleanup: removed ~/Applications/Video Preview Spike.app, lsregister -u, qlmanage -r; pluginkit no match.
  Removed scratch samples/builds. No temp keychain was ever created. Kept: _tmp/video-preview-spike samples,
  ~/.cache/mac-utilities/vlckit/VLCKit-3.7.3.tar.xz (fetch cache), scratch logs.
- Built video-preview/ (xcodeproj generated deterministically, scripts, app UI, extension), icon.
- lifecycle app.extensions + tests; build.py hook + verify_bundle; fixtures + tests; workflows pin Xcode 15.4 + VLCKit cache.
- Local: test.sh green; release build + isolated install/update of all apps OK; dev app plays all 5 formats.
- VERSION 1.4.0, SCRIPT_VERSION v1.4.0, CHANGELOG; gate OK.
- PR #14 opened; CI running. Asked (main) for user's Space check on 5 dev samples (_tmp/video-preview/).
- CI run 1 green but rg missing => */tests skipped; fixed test.sh (find), run 2 green with video-preview build tests on Xcode 15.4.
- Reported PR #14 green to (main). Waiting for user's Space check; then remove Video Preview Dev.app.
- USER-VERIFIED (via main): all 5 samples (webm, mkv, avi, flv, wmv) play in QL panel with tone, loop, click pauses/resumes. Host-app window NOT user-verified.
- Removed ~/Applications/Video Preview Dev.app (pluginkit -r, lsregister -u, qlmanage -r); pluginkit lists no video-preview extension. Removed dev builds/samples from scratch; _tmp/video-preview samples kept.
- 2026-10-06 PR #14 merged by (main) as 25f767c (squash). Not tagged. Idle; (main) runs close-out with the release.
