# Task plan: Video Preview utility (video-preview) → v1.4.0 PR

Source: (main) message after spike GO. Spike branch video-preview-spike @200df97 (pushed, not merged).

## Phases
1. [complete] Survey repo conventions: gif-stickers layout, manifests, build.py, install hooks, tests, release.yml/ci.yml
2. [complete] video-preview/: xcodeproj (app+appex), fetch-vlckit.sh (+~/.cache), build.sh (flat dylib, inside-out ad hoc), UTIs, entitlements
3. [complete] Host app window: description, formats, extension status (pluginkit), Refresh Quick Look, LGPL notice
4. [complete] Extra containers (avi, flv, ogv, wmv) only if each verified with generated sample
5. [complete] Release integration: build.py xcodebuild type/hook, arch+signature+entitlement checks; ci/release.yml VLCKit fetch+cache, pinned Xcode on macos-14; LGPL text in app Resources + repo
6. [complete] mac-utility.json + install/uninstall hooks; utility README; root README table; docs quarantine + no sidecar subs
7. [complete] Tests: scripts test for relink/signatures; release fixtures include new app
8. [complete] Local verification with DEV bundle (Video Preview Dev.app, com.mac-utilities.video-preview.dev); remove after
9. [complete] Release prep: VERSION 1.4.0, SCRIPT_VERSION v1.4.0, CHANGELOG [1.4.0], version gate
10. [complete: PR #14 merged 25f767c] Commit, push, PR; CI green (prove Xcode on macos-14); report PR URL to (main)

## Rules
- /bin/bash 3.2; older Swift on runner; no personal data; no-reply identity; one PR; no merge/tag/release; no Computer Use.
- Never install release bundle id; never touch user's installed apps/receipts.

## Decisions
- Host app not sandboxed (only appex must be); app runs pluginkit/qlmanage.
- Registration done by manager lifecycle (`app.extensions`) after move; install hook stages only.
- Release: `release.build` hook in manifest; build.py verify_bundle for all apps.
- VLCKit linked via -F search path (no framework file ref), so vendor dir can live anywhere; install hook uses temp vendor.
- Formats: mkv, webm, avi, flv, wmv (verified via qlmanage + generated samples); ogv dropped (no Theora encoder).
- Xcode 15.4 pinned on macos-14.

## Errors
- minos parse: VLCKit x86_64 slice uses LC_VERSION_MIN_MACOSX (10.9) -> minimums() reads both.
- CATALOG count test expected 5 -> len(CATALOG).
