# Findings: video-preview utility

## Utility phase
- Manager install hooks write into a STAGE Applications dir; manager moves app afterwards and runs
  no uninstall hook for non-privileged utilities => extension registration must live in lifecycle.
- build.py + install.py both refuse symlinks (kept). lifecycle payload copies the source tree:
  Vendor/ added to IGNORE in build.py and lifecycle.py; install hook uses temp vendor dir.
- UTIs on macOS 27: public.avi, com.adobe.flash.video, com.microsoft.windows-media-wmv are CoreTypes;
  org.webmproject.webm CoreTypes; org.matroska.mkv only from VLC.app -> imported decls for all five.
- All five play via qlmanage (Playback started 640x360, audio tracks 2). ogv: no libtheora in brew ffmpeg.
- VLCKit dylib: arm64 minos 11.0; x86_64 LC_VERSION_MIN_MACOSX 10.9.
- VLCKit logs "option quiet does not exist" at error level every preview (filtered).
- Release zip for Video Preview: 35.1 MB. Full local release build + isolated install/update OK.

# Spike


### VERDICT: GO
An ad-hoc-signed (`codesign --sign -`) Quick Look preview extension that embeds VLCKit 3.7.3
loads, runs in the App Sandbox and plays MKV and WebM with sound, looping, when installed
the way our installer does it: curl download (no quarantine), ~/Applications, host app
launched once. USER-VERIFIED 2026-10-06 in Finder (Space): both samples play in the panel,
tone audible, both loop. (System Settings Quick Look listing not checked.)
Condition: VLCKit must ship as a flat dylib, not a framework (the release pipeline refuses
symlinks). Browser downloads (quarantined) need Gatekeeper approval, like every ad-hoc app.

### Signing recipe that works (ad hoc, no hardened runtime)
1. xcodebuild ... -destination 'generic/platform=macOS' CODE_SIGNING_ALLOWED=NO build
2. Flatten: cp VLCKit.framework/Versions/A/VLCKit -> appex/Contents/Frameworks/VLCKit.dylib;
   rm the framework; install_name_tool -id @rpath/VLCKit.dylib on it;
   install_name_tool -change @loader_path/../Frameworks/VLCKit.framework/Versions/A/VLCKit
   @rpath/VLCKit.dylib on the appex binary (rpath @executable_path/../Frameworks is set).
3. codesign --force --sign - --timestamp=none appex/Contents/Frameworks/VLCKit.dylib
4. codesign --force --sign - --timestamp=none --entitlements PreviewExtension.entitlements <appex>
5. codesign --force --sign - --timestamp=none --entitlements App.entitlements <app>
6. codesign --verify --deep --strict <app>
(spikes/video-preview/scripts/build.sh with LAYOUT=dylib does exactly this.)

### Entitlements
- appex: com.apple.security.app-sandbox, com.apple.security.files.user-selected.read-only.
  Nothing else needed: no network, no disable-library-validation, no JIT. QL grants file read.
- app: com.apple.security.app-sandbox (not strictly required for the host; kept minimal).
- Unsigned/entitlement-less appex is ignored by pkd: "plug-ins must be sandboxed".

### What the real utility (`video-preview`) needs
- Top-level `video-preview/` folder: xcodeproj (app + appex), fetch-vlckit.sh pinned
  (URL + SHA-256 above), build script with the flatten + inside-out signing; Vendor/ gitignored.
- Host app Info.plist: UTImportedTypeDeclarations for org.matroska.mkv (and webm for older macOS).
- Player: VLCMediaPlayer(videoView:) + delegate restart on end; NOT VLCMediaListPlayer/:input-repeat.
  Add pause on panel close (deinit stop works), mute/volume default, maybe size from track dims.
- Release builder (scripts/release/build.py): new app type built with xcodebuild (not SwiftPM);
  fetch VLCKit in CI (84 MB download, cache it); check both archs + signatures of appex and dylib;
  archive() symlink rule stays as is (flat dylib). Review resources (VLCKit COPYING = LGPL-2.1+:
  ship license text, keep dylib replaceable) before adding to release verification.
- Manifest mac-utility.json + installer hook: install app to ~/Applications, launch it once
  (or `pluginkit -a <appex>` / lsregister) so the extension registers; `qlmanage -r` after
  install/update; uninstall = remove app then `qlmanage -r`. No SwiftBar plugin.
- CI: macos-14 runner default Xcode (15.4) not yet proven; first CI run should confirm, or
  pin Xcode via xcode-select in the workflow.
- Docs: README should mention browser-downloaded zips need "Open Anyway" / --strip-quarantine,
  and that sidecar subtitle files are not auto-loaded (sandbox).

### Environment
- macOS 27.0 (26A428), Xcode 27.0 (27A266a), Apple Silicon. ffmpeg (Homebrew) for samples.
- No xcodegen/tuist: project.pbxproj hand-written (objectVersion 56).

### VLCKit
- Source: VideoLAN official CocoaPods binary mirror, latest stable 3.x = 3.7.3 (25 Feb 2026).
  URL https://download.videolan.org/pub/cocoapods/prod/VLCKit-3.7.3-319ed2c0-79128878.tar.xz
  SHA-256 019afdae4e2e2d0f3ac325fac8f7ba0af25dca70b9d157df7d60db88e0be8e5d (84.1 MB tar.xz;
  verified on two independent downloads; VideoLAN publishes no checksum file there).
- libvlc 3.0.23 "Vetinari". xcframework slice macos-arm64_x86_64, minos 11.0.
- ONE universal dylib (82 MB), libVLC plugins statically linked; no plugin dylibs.
  Ships ad-hoc signed by VideoLAN. Install name @loader_path/../Frameworks/VLCKit.framework/Versions/A/VLCKit.
  Versioned framework => 6 symlinks. Resources = Info.plist only.
- 424 MB extracted package (339 MB dSYMs, sample code, docs) — only the framework is used.

### UTIs (this Mac)
- org.webmproject.webm: declared by CoreTypes (Apple core type) on macOS 27.
- org.matroska.mkv: declared ONLY by VLC.app (imported). => host app must declare
  UTImportedTypeDeclarations for org.matroska.mkv (done; also webm for older macOS).

### VLCKit usage gotchas
- VLCMediaListPlayer(options:andDrawable:) never leaves Stopped (also outside sandbox, CLI harness).
- :input-repeat option ends Paused at EOF. Looping = delegate restarts on Ended/Paused-at-end.
- Plain VLCMediaPlayer(videoView:) works. state reports "Buffering" while playing (VLCKit quirk); use isPlaying/time.
- Forward VLC logs via a VLCLogging object on libraryInstance.loggers.

### Exp 1: ad-hoc, direct install (ditto) into ~/Applications, launched once
- pluginkit lists com.mac-utilities.video-preview-spike.preview (default state, no +/- election), path in ~/Applications.
- qlmanage -p webm + mkv: extension process launches, VLCKit loads, plays:
  playing=true, time advancing, hasVideoOut=true, AUHAL audio output opened, loops.
  WebM: demux mkv, video avcodec (VP9), audio opus. MKV: video videotoolbox/avcodec (H.264), audio avcodec (AAC).
- AMFI logs "adhoc signed ... not valid -423" for appex + VLCKit — informational only, load proceeds.
  No library-validation denial (no hardened runtime => LV not enforced; single dylib anyway).
- Sandbox denials (benign): system-info vfs.disk-space (x~50), mach-lookup backboard.hid-services,
  cmio.registerassistantservice, file-read-data on the PARENT folder (VLC directory scan for
  sibling subtitles -> sidecar .srt auto-load will not work in sandbox).
- Unsigned DerivedData copy is ignored by pkd: "plug-ins must be sandboxed" (needs entitlements via codesign).

### Exp 3: installer path
- Stock framework layout: scripts/release/build.py archive() REFUSES ("Release archives cannot contain
  symlinks: ...VLCKit.framework/Resources"); ditto-zip + install.py extract() also REFUSES
  ("Archive contains a symlink or special file").
- LAYOUT=dylib (Contents/Frameworks/VLCKit.dylib, install_name_tool -id @rpath/VLCKit.dylib,
  -change in appex binary, then re-sign): build.archive OK -> loopback HTTP -> curl (no xattrs) ->
  install.extract OK -> ditto to ~/Applications -> launch -> pluginkit registered -> both files play + loop.
  Same benign denials only.
- WITH quarantine (0083;...;Safari; — same flag Safari writes): extract() propagates quarantine to the app
  (copy_quarantine). open -> App Translocation + Gatekeeper prompt ("Prompt shown, waiting for response",
  "rejecting due to lack of matching active rule"); extension NOT registered (pluginkit no match) ->
  QL falls back to system preview. Same as any ad-hoc app: needs Privacy & Security "Open Anyway"
  or installer's --strip-quarantine.

### Exp 4: not needed (ad-hoc works). disable-library-validation / self-signed not tried.

### Exp 5: sizes / CI
- VLCKit.framework 81 MB on disk (78 MB after RemoveHeadersOnCopy); app 78 MB; app zip 34.9 MB.
- CI: ci.yml/release.yml run on macos-14 with no Xcode selection => runner default Xcode
  (runner-images macos-14: Xcode 15.4 default, 15.x/16.x installed). Not verified by pushing.
- User verified all five formats in Finder (Space): playback, sound, loop, click pause/resume. Host-app window not user-verified.
