# gif-stickers: turn GIFs into WhatsApp stickers (Mac utility)

## Goal
A small native Mac app that turns an animated GIF into a WhatsApp sticker.
GIFs rarely come square. The GIF must keep its own aspect ratio on screen,
and the user chooses the result with a square selection frame laid over it:
drag to pan, resize or scroll to zoom, so the square picks the crop. Also
offer a "fit" mode that letterboxes the whole GIF inside the square with
transparent padding. Show a live preview of the actual sticker (looping,
at output size) next to the editor.

## Deliverable
- `gif-stickers/` at the repo root (the "bigger utility" shape in AGENTS.md):
  a SwiftUI app built with `swift build` or `xcodebuild` (Xcode is installed),
  plus `README.md` and a `scripts/install.sh` that builds and puts the app in
  `~/Applications`.
- Open a GIF via File > Open and drag-and-drop onto the window/dock icon.
- Export to the WhatsApp animated sticker format. Verify the current spec
  first and record it in findings.md; as of 2026 it is WebP, exactly 512x512,
  animated ones at most 500 KB and at most 10 s, static ones at most 100 KB,
  transparency allowed. The exporter must auto-tune (quality, fps, trimming
  to the duration cap) until the file is under the size cap, and tell the
  user what it did.
- Getting it into WhatsApp: at minimum save the .webp and copy it to the
  clipboard, and reveal it in Finder. Investigate what WhatsApp Desktop on
  macOS accepts (drag-drop of a .webp as a sticker?) and document the
  smoothest path you find. Do not build any messaging integration.

## Approach
1. Spike first: using `/opt/homebrew/bin/ffmpeg`, `gif2webp` and `img2webp`
   (all installed) or Apple's ImageIO, prove the pipeline on a sample GIF
   from the command line: crop square, scale to 512, encode WebP under
   500 KB. Write what works and the size/quality numbers to findings.md
   before touching UI. If ImageIO can encode animated WebP natively on this
   macOS, prefer it (no runtime dependency); otherwise shelling out to the
   Homebrew webp tools is acceptable, documented in the README, with a clear
   error in the app if they are missing.
2. Then the UI. Keep it to one window: GIF with the square selector on the
   left, sticker preview on the right, crop/fit toggle, an export button,
   and a line showing the resulting size and duration.

## Rules
- Follow AGENTS.md. Work and commit only on branch `gif-stickers` in this
  worktree; open a PR to `main` when it is verified; never touch `main`.
- Planning notes go in the gitignored root files `task_plan.md`,
  `findings.md`, `progress.md`. Never commit `.planning/` or this brief.
- `_tmp/` is the user's iCloud inbox: look there for sample GIFs or
  screenshots they drop, and write preview renders there for them to see.
- No third-party Swift packages unless unavoidable; say why if you add one.

## When to stop
Stop and report when a built app opens a GIF, lets the user frame the square,
previews the sticker, and exports a WebP that meets the spec, with the README
written. Stop earlier and ask if the spike shows the format cannot be produced
with the tools on this Mac, or if a design decision materially changes the
scope.
