# Findings
- App uses a single EditorModel and SwiftUI EditorView; export and preview share ExportResult.data.
- Empty left box is currently passive text. Loaded box has independent crop gestures.
- Tests are an executable-target XCTest package, macOS 14+, without third-party Swift dependencies.
- Brief explicitly authorizes one feature PR, forbids installation and real messages, and requires optional Keychain basic auth.
- Local GOWA GET /app/devices returns {code: SUCCESS, results: [{device, jid, name}]}; /app/status returns connection/login flags. Never decode/display names.
- SendSticker reads multipart sticker and phone fields, preserves animated 512x512 WebP <=500 KiB, sets IsAnimated. Our encoder cap is stricter (500,000 bytes).
- Server success/error messages may include recipient data: use only sanitized local errors and success text.
- Configured commit identity is a GitHub no-reply identity.
- X-Device-Id chooses the GOWA sending account. Normalize linked-device JIDs to the user's bare JID for Message yourself.
- Animated-only send ensures GOWA preserves exact bytes. Static preview remains exportable.
- Older bridge compatibility: device itself may contain JID; missing /app/status (404 only) falls back to device discovery.
- UI stub success received a valid 4,804-byte animated 512x512 WebP, six frames, 900 ms total; webpmux independently verified it.
- New send status exceeded the original window's height; increased default/minimum height so feedback fits.
- Native automation had capture errors, then recovered after restarting only the scratch verification process. App sample showed a responsive main event loop.

## Deferred SayWhat daemon contract (reported by sw:daemon-send-endpoint)
- Implementation in progress, not installed yet. POST loopback port 3220 /send, always self-chat; no recipient fields accepted.
- Read ~/.local/share/saywhat/send.secret, trimmed 64-character hex string; HMAC key is UTF-8 of the string, not hex-decoded bytes. Never use a command-line argument for it.
- X-Saywhat-Timestamp integer Unix seconds; X-Saywhat-Signature sha256=lowercase hex HMAC-SHA256(secretUTF8, timestamp + '.' + raw multipart Data). Freshness window 300 seconds.
- Multipart exactly kind=sticker and file with filename + image/webp. Signed bytes must equal uploaded bytes; daemon preserves animated 512x512 WebP <=512000 bytes. App encoder remains stricter at 500000 bytes.
- 200 JSON ok/message_id/chat_jid/kind (ignore chat_jid); error JSON ok=false/code/error. Need review safe error handling since gowa_refused may contain upstream message.
- Requested readiness probe contract without recipient data; not provided in first handoff.

## Active library / signed-send follow-up
- Coordinator relays user request for library + signed send in one PR for 1.1.0; fresh branch gif-stickers-library begins at 4217971.
- Read-only SayWhat branch AGENTS.md and selfsend.rs confirm /send v1 contract. Still stickers also supported. Current app remains WebP-only with conservative 500000/100000 caps and exact 512 dimensions.
- GET /health returns gowa.ok independently of overall ok/transcriber status; only decode gowa.ok, never account/device details.
- Library defaults to Pictures/GIF Stickers; JSON library_folder absolute path, preserve other keys. Files remain in old folder after selection changes. Imports copy bytes, exports create unique copies, deletes go to Trash.
- Production signed endpoint fixed to IPv4 loopback 3220; test constructors inject ephemeral loopback URL and temporary key. Redirects refused. No personal response strings displayed/logged.
