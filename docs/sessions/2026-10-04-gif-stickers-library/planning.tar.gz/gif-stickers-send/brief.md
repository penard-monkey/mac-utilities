# GIF Stickers: click-to-open drop zone, and "Send to my WhatsApp"

Two user-requested changes to gif-stickers/ (SwiftUI app). Ship as one PR.

## 1. Click the left box to open a file
Today the left "Frame your animation" box only accepts drag and drop; clicking
it does nothing. Make a click (and keyboard activation for accessibility) on the
empty drop zone open the same NSOpenPanel as File > Open (GIF + MP4/M4V/MOV).
When a file is already loaded, clicks inside the box must keep working for the
crop square (drag/resize) and must NOT open the panel; offer a small "Choose
another file…" control instead. Keep drag and drop working in both states.

## 2. "Send to my WhatsApp"
Next to Export, a button that sends the exact previewed WebP as an animated
sticker to the user's own WhatsApp ("Message yourself" chat), so they can
favourite it on the phone. It uses a local GOWA bridge
(aldinokemal/go-whatsapp-web-multidevice; the user runs it for another app):
- Default base URL http://127.0.0.1:3210, configurable in
  ~/.config/mac-utilities/gif-stickers.json (`whatsapp_bridge_url`). No auth
  is configured on this Mac; support optional basic-auth credentials stored in
  the macOS Keychain, never in the JSON or the repo.
- Find the user's own number from the bridge (GET /app/devices, or the
  equivalent user/device endpoint; read the GOWA source at
  ~/workspace/go-whatsapp-web-multidevice/src read-only). Never hard-code or
  log a phone number; never put one in the repo, tests or docs.
- Send with POST /send/sticker as multipart field `sticker` (see
  src/ui/rest/send.go and usecase/send.go SendSticker: an animated WebP that is
  exactly 512x512 and under 500 KB is sent as-is with IsAnimated).
- Only show/enable the button when the bridge answers a quick health/devices
  probe; otherwise hide it or explain in a tooltip. Show clear success/failure.
  Confirm before sending ("Send this sticker to your own WhatsApp chat?").
- Document it in gif-stickers/README.md as optional, needing a local GOWA
  bridge, and explain the favourite-it-on-the-phone step.

## Tests and verification
- Unit tests with a stub HTTP server for: bridge probe, own-JID discovery,
  multipart upload shape, error handling. No real network in tests.
- Verify the UI in an isolated run (a locally built app from your worktree's
  build folder is fine; do NOT install it into ~/Applications and do not touch
  the user's installed apps or ~/Library/Application Support/mac-utilities:
  installs change only via releases).
- Do NOT send any real WhatsApp message. The user will do the first real send
  after release.
- Bump gif-stickers/mac-utility.json version to 1.1.0 and add a CHANGELOG
  line under a new "Unreleased" heading at the top (the release version is
  decided when we cut it; another lane is preparing 1.1.0 for Git & SSH).

## Rules
Follow AGENTS.md (incl. the /bin/bash 3.2 rule). The repo is PUBLIC: no
personal names, emails, phone numbers or paths. Commit only on this branch with
the configured no-reply identity; open one PR to main; never merge, tag or
release. Planning in gitignored root task_plan.md / findings.md / progress.md.
Report to (main) via worktrees report with the PR URL when CI is green.
