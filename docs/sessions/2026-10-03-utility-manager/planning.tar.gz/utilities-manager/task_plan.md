# Task Plan: Utilities manager

## Goal
Deliver a selective receipt-protected lifecycle backend and functioning native SwiftUI Mac Utilities app, tested in isolation and committed for the coordinator.

## Next Step
Coordinator integrates commit 5a65f472f058a28fa37f3679a8be927a36279823 and rebuilds the complete catalog.

## Current Phase
Phase 4

## Phases
### Phase 1: Scope and contracts
- [x] Read brief and place guidance
- [x] Report exact manifest contract
- **Status:** complete
### Phase 2: Backend and selective installer
- [x] Build stable payload installation, status, update, visibility, and uninstall
- [x] Add memory and Travel Router manifests
- **Status:** complete
### Phase 3: Native manager
- [x] Build SwiftUI catalog and actions with asynchronous backend
- [x] Package signed app with backend and catalog
- **Status:** complete
### Phase 4: Verification and handoff
- [x] Test lifecycle in temporary roots with mock hooks
- [x] Build native app
- [x] Commit owned files and report hash, tests and limitations
- **Status:** complete

## Open Questions
- Integration manifests for coordinator-owned Tools/GIF and other lane Git & SSH.

## Decisions Made
| Decision | Rationale |
|---|---|
| Keep planning in .planning | Native workspace with persistent task brief, rather than unavailable container paths |
| Never execute Travel Router hooks here | Brief forbids privileged networking changes |

## Errors Encountered
| Error | Attempt | Resolution |
|---|---|---|
| worktrees messages CLI unavailable | 1 | Discover MCP report/messages capabilities instead |
| py_compile default cache outside sandbox | 1 | Use PYTHONDONTWRITEBYTECODE for tests, redirected cache for explicit compile |
| Two lifecycle test fixture failures | 1 | Canonicalize temp path and give fixture utilities distinct plugin filenames |
| Self installer exception identity mismatch in test | 1 | Register imported lifecycle module in sys.modules |
| Direct sandboxed GUI launch exit 134 | 1 | Launch preview via native CUA; read-only window/screenshot inspection succeeded |
| Empty Bash array with nounset | 1 | Replace optional build array with positional arguments |

## Completion
Committed 5a65f472f058a28fa37f3679a8be927a36279823 and sent coordinator full handoff. Working tree clean. No push or merge.
