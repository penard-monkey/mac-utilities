# Findings

## Requirements
- Own utilities-manager/, scripts/install.sh, memory/Travel Router manifests only.
- Five catalog entries: tools, memory, travel-router, gif-stickers, git-settings.
- Stable payloads under ~/Library/Application Support/mac-utilities; SwiftBar only ~/.swiftbar.
- Preserve preferences and Git/SSH keys; receipts guard deletion.
- Native SwiftUI app using SPM; ad hoc signed bundle installer.
- No host installs or privileged networking changes; temporary-root lifecycle tests.

## Research Findings
- Place starts clean at origin/main a269ab1.
- Existing root installer links every plugin into worktree sources and updates SwiftBar preference.
- worktrees CLI version lacks report/messages commands; discover MCP equivalents.

## Technical & Strategic Decisions
| Decision | Rationale |
|---|---|
| Standard-library Python 3.9 backend | Required system Python compatibility |

## Open Issues
| Issue | Status / Resolution |
|---|---|
| Manifest contracts | Inspect then send coordinator |

## Sources
- .planning/brief.md, AGENTS.md, scripts/install.sh, worktrees guide

- Coordinator accepts installed-tools.json array and manifest contract; owns Tools/GIF manifests. Existing legacy links exist on host; migrate only same-repository plugin symlinks, retaining original targets for rollback.
- GIF needs optional img2webp dependency detection, no Homebrew installation. Travel Router must label payload staged separately from existing system files.
- Native window and bundle installer created; bundled catalog is independent of worktree lifetime.

- Final 15 standard-library lifecycle tests pass on /usr/bin/python3 3.9.6. They verify plugin/app preservation, transaction rollback, metadata rollback, legacy provenance, mocked privileged hooks, dependency status, CLI dispatch and bulk selection, and manager bundle receipts.
- Ad hoc signed release app built successfully; CUA inspected live five-entry window and screenshot, then quit the preview. GUI launched through CUA without isolated environment, so UI inspection remained read-only. Initial sandboxed direct launch exit 134 resolved through native launch.
- Other lanes own absent Tools/GIF/Git sources: final full-catalog bundling belongs to coordinator integration.
