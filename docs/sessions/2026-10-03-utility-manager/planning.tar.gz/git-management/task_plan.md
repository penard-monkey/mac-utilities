# Task Plan: Mac Utilities and Git & SSH

## Goal
Build and integrate a selective native Mac Utilities installer/manager and a native machine-level Git & SSH app, using Sol agents in managed worktree places, launched from the existing Tools plugin.

## Next Step
Complete: PR #12 open, unmerged; reported to (main).

## Current Phase
Phase 5

## Phases
### Phase 1: Scope and delegation
- [x] Inspect existing launcher and installer
- [x] Launch separate Sol worktree lanes
- **Status:** complete
### Phase 2: Implementation and integration
- [x] Integrate committed GIF Stickers and Tools launcher
- [x] Build selective installer and native management UI
- [x] Build Git & SSH configuration UI
- **Status:** complete
### Phase 3: Verification
- [x] Review and integrate lane commits
- [x] Build/test isolated fixtures and inspect native UI
- [x] Check installed launcher integration
- **Status:** complete
### Phase 4: Delivery
- [x] Commit integrated changes and report usage/limitations
- **Status:** complete

## Decisions Made
| Decision | Rationale |
|---|---|
| Use gpt-6.1-sol via worktrees Codex lanes | User explicitly requested Sol in another place |
| Keep native apps independent and shared launcher small | Existing repository conventions and launcher support this |
| Keep planning under .planning in this persistent Mac checkout | Container-only skill paths do not apply here |
| Preserve SSH keys and Git configs on uninstall | These are user-owned machine configuration |

## Errors Encountered
| Error | Attempt | Resolution |
|---|---|---|
| worktrees new --help unsupported | 1 | Used guide and MCP tool schema |
| git fetch sandbox denied FETCH_HEAD | 1 | Approved escalation succeeded |
| No .planning directory yet | 1 | Created new task plan |

## Verification outcomes
- 15 manager lifecycle tests, 5 launcher tests, 12 Git core tests, 4 GIF regression tests passed.
- Native Git UI fixture preview/apply/restore passed.
- Full bundled catalog Git install/menu/open/uninstall passed in isolated home.
- Host manager, Tools, Git & SSH and GIF Stickers installed with valid signatures/healthy receipts.
- Memory/Travel host plugin links preserved; no real Git/SSH edits or networking changes.

### Phase 5: Publish integrated PR
- [x] Merge latest origin/main and preserve Bash-compatible installer
- [x] Rerun all 36 tests and relevant checks
- [x] Push and open one PR, report URL to (main), do not merge
- **Status:** complete
